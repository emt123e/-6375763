"""
应用入口文件
"""
import os
from dotenv import load_dotenv

# 加载环境变量
load_dotenv()

from app import create_app, db
from app.models import User, Role, SentimentReport, SystemSetting

# 创建应用实例
app = create_app(os.getenv('FLASK_ENV', 'development'))


@app.shell_context_processor
def make_shell_context():
    """为flask shell添加上下文"""
    return {
        'db': db,
        'User': User,
        'Role': Role,
        'SentimentReport': SentimentReport,
        'SystemSetting': SystemSetting
    }


if __name__ == '__main__':
    app.run(host='127.0.0.1', port=5000, debug=True)
