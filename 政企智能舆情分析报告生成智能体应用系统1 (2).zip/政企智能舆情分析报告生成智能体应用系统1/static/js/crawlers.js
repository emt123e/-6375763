layui.use(['layer', 'form', 'element'], function(){
    var layer = layui.layer;
    var form = layui.form;
    var $ = layui.$;
    
    function loadCrawlers() {
        fetch('/admin/api/crawlers')
            .then(response => response.json())
            .then(data => {
                if(data.code === 0) {
                    renderCrawlers(data.data);
                }
            });
    }
    
    function renderCrawlers(crawlers) {
        var container = $('#crawler-grid');
        var emptyState = $('#empty-state');
        
        if(crawlers.length === 0) {
            container.hide();
            emptyState.show();
            return;
        }
        
        container.show();
        emptyState.hide();
        
        var html = '';
        crawlers.forEach(function(crawler) {
            var statusClass = crawler.is_enabled ? '' : 'disabled';
            var defaultBadge = crawler.is_default ? '<span class="crawler-default-badge">默认</span>' : '';
            var typeLabel = {'baidu': '百度新闻', 'xinhua': '新华网', 'custom': '自定义'}[crawler.crawler_type] || crawler.crawler_type;
            var successRate = crawler.crawl_count > 0 ? Math.round((crawler.success_count / crawler.crawl_count) * 100) + '%' : '-';
            
            html += '<div class="crawler-card ' + statusClass + '" data-id="' + crawler.id + '">' +
                '<div class="crawler-card-header" style="background: linear-gradient(135deg, ' + crawler.color + ' 0%, ' + adjustColor(crawler.color, -30) + ' 100%);">' +
                    defaultBadge +
                    '<div class="crawler-icon"><i class="layui-icon ' + crawler.icon + '"></i></div>' +
                    '<div class="crawler-name">' + crawler.name + '</div>' +
                    '<div class="crawler-type"><span class="type-tag ' + crawler.crawler_type + '">' + typeLabel + '</span></div>' +
                '</div>' +
                '<div class="crawler-card-body">' +
                    '<div class="crawler-info-item"><i class="layui-icon layui-icon-link"></i><span class="label">基础URL</span><span class="value">' + (crawler.base_url || '-') + '</span></div>' +
                    '<div class="crawler-info-item"><i class="layui-icon layui-icon-time"></i><span class="label">最后采集</span><span class="value">' + (crawler.last_crawl_at || '从未') + '</span></div>' +
                    '<div class="crawler-info-item"><i class="layui-icon layui-icon-note"></i><span class="label">描述</span><span class="value">' + (crawler.description || '-') + '</span></div>' +
                '</div>' +
                '<div class="crawler-stats">' +
                    '<div class="crawler-stat"><div class="crawler-stat-value">' + (crawler.crawl_count || 0) + '</div><div class="crawler-stat-label">采集次数</div></div>' +
                    '<div class="crawler-stat"><div class="crawler-stat-value">' + (crawler.success_count || 0) + '</div><div class="crawler-stat-label">成功次数</div></div>' +
                    '<div class="crawler-stat"><div class="crawler-stat-value">' + successRate + '</div><div class="crawler-stat-label">成功率</div></div>' +
                '</div>' +
                '<div class="crawler-card-footer">' +
                    '<button class="layui-btn layui-btn-sm layui-btn-warm" onclick="testCrawler(' + crawler.id + ')"><i class="layui-icon layui-icon-release"></i> 测试</button>' +
                    '<button class="layui-btn layui-btn-sm layui-btn-normal" onclick="editCrawler(' + crawler.id + ')"><i class="layui-icon layui-icon-edit"></i></button>' +
                    '<button class="layui-btn layui-btn-sm layui-btn-danger" onclick="deleteCrawler(' + crawler.id + ')"><i class="layui-icon layui-icon-delete"></i></button>' +
                '</div>' +
            '</div>';
        });
        
        container.html(html);
    }
    
    function adjustColor(color, amount) {
        var usePound = false;
        if (color[0] === "#") { color = color.slice(1); usePound = true; }
        var num = parseInt(color, 16);
        var r = Math.min(255, Math.max(0, (num >> 16) + amount));
        var g = Math.min(255, Math.max(0, ((num >> 8) & 0x00FF) + amount));
        var b = Math.min(255, Math.max(0, (num & 0x0000FF) + amount));
        return (usePound ? "#" : "") + (0x1000000 + r * 0x10000 + g * 0x100 + b).toString(16).slice(1);
    }
    
    $('#btn-init-crawlers').on('click', function() {
        layer.confirm('确定要初始化默认爬虫配置吗？', {icon: 3, title: '提示'}, function(index) {
            var defaultCrawlers = [
                {name: '百度新闻', crawler_type: 'baidu', description: '百度新闻搜索', base_url: 'https://www.baidu.com/s', is_enabled: true, is_default: true, priority: 100, icon: 'layui-icon-search', color: '#3385FF'},
                {name: '新华网四川', crawler_type: 'xinhua', description: '新华网四川频道', base_url: 'http://sc.news.cn/scyw.htm', is_enabled: true, is_default: false, priority: 90, icon: 'layui-icon-read', color: '#D81E06'}
            ];
            
            var promises = defaultCrawlers.map(function(crawler) {
                return fetch('/admin/api/crawlers', {method: 'POST', headers: {'Content-Type': 'application/json'}, body: JSON.stringify(crawler)}).then(r => r.json());
            });
            
            Promise.all(promises).then(function(results) {
                var successCount = results.filter(r => r.code === 0).length;
                layer.msg('成功添加 ' + successCount + ' 个默认爬虫', {icon: 1});
                loadCrawlers();
            });
            layer.close(index);
        });
    });
    
    $('#btn-add-crawler').on('click', function() { openCrawlerForm(); });
    
    function openCrawlerForm(crawlerData) {
        var isEdit = !!crawlerData;
        var title = isEdit ? '编辑爬虫' : '新增爬虫';
        
        layer.open({
            type: 1,
            title: '<i class="layui-icon layui-icon-website" style="color:#1E9FFF;margin-right:5px;"></i>' + title,
            area: ['700px', '550px'],
            content: $('#crawler-form-tpl').html(),
            success: function(layero, index) {
                form.render();
                
                if(isEdit) {
                    layero.find('input[name="id"]').val(crawlerData.id);
                    layero.find('input[name="name"]').val(crawlerData.name);
                    layero.find('select[name="crawler_type"]').val(crawlerData.crawler_type);
                    layero.find('input[name="base_url"]').val(crawlerData.base_url);
                    layero.find('input[name="search_url"]').val(crawlerData.search_url);
                    layero.find('select[name="encoding"]').val(crawlerData.encoding);
                    layero.find('input[name="request_timeout"]').val(crawlerData.request_timeout);
                    layero.find('input[name="priority"]').val(crawlerData.priority);
                    layero.find('textarea[name="description"]').val(crawlerData.description || '');
                    layero.find('select[name="icon"]').val(crawlerData.icon);
                    layero.find('input[name="color"]').val(crawlerData.color);
                    if(!crawlerData.is_enabled) { layero.find('input[name="is_enabled"]').removeAttr('checked'); }
                    form.render();
                }
                
                form.on('submit(crawler-submit)', function(data) {
                    var formData = data.field;
                    formData.is_enabled = formData.is_enabled === 'on';
                    formData.request_timeout = parseInt(formData.request_timeout);
                    formData.priority = parseInt(formData.priority);
                    
                    var url = isEdit ? '/admin/api/crawlers/' + formData.id : '/admin/api/crawlers';
                    var method = isEdit ? 'PUT' : 'POST';
                    
                    fetch(url, {method: method, headers: {'Content-Type': 'application/json'}, body: JSON.stringify(formData)})
                        .then(response => response.json())
                        .then(result => {
                            if(result.code === 0) {
                                layer.msg(result.msg, {icon: 1});
                                layer.close(index);
                                loadCrawlers();
                            } else {
                                layer.msg(result.msg, {icon: 2});
                            }
                        });
                    return false;
                });
            }
        });
    }
    
    window.editCrawler = function(id) {
        fetch('/admin/api/crawlers/' + id)
            .then(response => response.json())
            .then(data => { if(data.code === 0) { openCrawlerForm(data.data); } });
    };
    
    window.deleteCrawler = function(id) {
        layer.confirm('确定要删除这个爬虫配置吗？', {icon: 3, title: '提示'}, function(index) {
            fetch('/admin/api/crawlers/' + id, {method: 'DELETE'})
                .then(response => response.json())
                .then(result => {
                    if(result.code === 0) { layer.msg(result.msg, {icon: 1}); loadCrawlers(); }
                    else { layer.msg(result.msg, {icon: 2}); }
                });
            layer.close(index);
        });
    };
    
    window.testCrawler = function(id) {
        var loadIndex = layer.load(1, {shade: [0.3, '#000']});
        fetch('/admin/api/crawlers/' + id + '/test', {method: 'POST'})
            .then(response => response.json())
            .then(result => {
                layer.close(loadIndex);
                if(result.code === 0) {
                    layer.msg('连接测试成功！状态码: ' + result.data.status_code, {icon: 1});
                    loadCrawlers();
                } else {
                    layer.msg(result.msg, {icon: 2});
                    loadCrawlers();
                }
            })
            .catch(err => { layer.close(loadIndex); layer.msg('测试请求失败', {icon: 2}); });
    };
    
    loadCrawlers();
});
