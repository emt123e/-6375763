"""
应用测试
"""
import pytest
from app import create_app, db


@pytest.fixture
def app():
    """创建测试应用"""
    app = create_app('testing')
    with app.app_context():
        db.create_all()
        yield app
        db.drop_all()


@pytest.fixture
def client(app):
    """创建测试客户端"""
    return app.test_client()


def test_index(client):
    """测试首页"""
    response = client.get('/')
    assert response.status_code == 200


def test_health_check(client):
    """测试健康检查接口"""
    response = client.get('/api/health')
    assert response.status_code == 200
    data = response.get_json()
    assert data['status'] == 'ok'


def test_get_reports(client):
    """测试获取报告列表"""
    response = client.get('/api/reports')
    assert response.status_code == 200
    data = response.get_json()
    assert data['code'] == 0


def test_create_report(client):
    """测试创建报告"""
    response = client.post('/api/reports', json={
        'title': '测试舆情报告',
        'content': '这是测试内容',
        'source': '测试来源',
        'sentiment': 'positive'
    })
    assert response.status_code == 200
    data = response.get_json()
    assert data['code'] == 0
    assert data['data']['title'] == '测试舆情报告'
