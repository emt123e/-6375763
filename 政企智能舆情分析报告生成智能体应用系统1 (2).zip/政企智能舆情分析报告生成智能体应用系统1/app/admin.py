"""
后台管理模块 - 用户管理、角色管理、系统设置
"""
import os
from functools import wraps
from flask import Blueprint, render_template, request, jsonify, current_app
from flask_login import login_required, current_user
from werkzeug.utils import secure_filename
from app import db
from app.models import User, Role, SystemSetting, CollectedData, CrawlRule, AIEngine, CrawlerConfig
from app.crawler import fetch_news, BaiduNewsCrawler, fetch_xinhua_news

# 创建后台管理蓝图
admin_bp = Blueprint('admin', __name__, url_prefix='/admin')


def admin_required(f):
    """管理员权限装饰器"""
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if not current_user.is_authenticated:
            return jsonify({'code': 401, 'msg': '请先登录'})
        if not current_user.is_admin():
            return jsonify({'code': 403, 'msg': '权限不足，需要管理员权限'})
        return f(*args, **kwargs)
    return decorated_function


# ==================== 页面路由 ====================

@admin_bp.route('/')
@login_required
@admin_required
def index():
    """后台管理首页"""
    return render_template('admin/index.html')


@admin_bp.route('/users')
@login_required
@admin_required
def users_page():
    """用户管理页面"""
    return render_template('admin/users.html')


@admin_bp.route('/roles')
@login_required
@admin_required
def roles_page():
    """角色管理页面"""
    return render_template('admin/roles.html')


@admin_bp.route('/settings')
@login_required
@admin_required
def settings_page():
    """系统设置页面"""
    return render_template('admin/settings.html')


# ==================== 用户管理API ====================

@admin_bp.route('/api/users', methods=['GET'])
@login_required
@admin_required
def get_users():
    """获取用户列表"""
    page = request.args.get('page', 1, type=int)
    limit = request.args.get('limit', 10, type=int)
    username = request.args.get('username', '')
    
    query = User.query
    if username:
        query = query.filter(User.username.like(f'%{username}%'))
    
    pagination = query.order_by(User.created_at.desc()).paginate(
        page=page, per_page=limit, error_out=False
    )
    
    users = [user.to_dict() for user in pagination.items]
    
    return jsonify({
        'code': 0,
        'msg': 'success',
        'count': pagination.total,
        'data': users
    })


@admin_bp.route('/api/users', methods=['POST'])
@login_required
@admin_required
def create_user():
    """创建用户"""
    data = request.get_json()
    
    username = data.get('username', '').strip()
    password = data.get('password', '')
    email = data.get('email', '').strip()
    realname = data.get('realname', '').strip()
    phone = data.get('phone', '').strip()
    role_id = data.get('role_id')
    is_active = data.get('is_active', True)
    
    if not username:
        return jsonify({'code': 1, 'msg': '用户名不能为空'})
    
    if not password:
        return jsonify({'code': 1, 'msg': '密码不能为空'})
    
    if len(password) < 6:
        return jsonify({'code': 1, 'msg': '密码长度不能少于6位'})
    
    # 检查用户名是否已存在
    if User.query.filter_by(username=username).first():
        return jsonify({'code': 1, 'msg': '用户名已存在'})
    
    # 检查邮箱是否已存在
    if email and User.query.filter_by(email=email).first():
        return jsonify({'code': 1, 'msg': '邮箱已被使用'})
    
    user = User(
        username=username,
        email=email if email else None,
        realname=realname,
        phone=phone,
        role_id=role_id,
        is_active=is_active
    )
    user.set_password(password)
    
    db.session.add(user)
    db.session.commit()
    
    return jsonify({'code': 0, 'msg': '创建成功', 'data': user.to_dict()})


@admin_bp.route('/api/users/<int:user_id>', methods=['GET'])
@login_required
@admin_required
def get_user(user_id):
    """获取单个用户"""
    user = User.query.get_or_404(user_id)
    return jsonify({'code': 0, 'data': user.to_dict()})


@admin_bp.route('/api/users/<int:user_id>', methods=['PUT'])
@login_required
@admin_required
def update_user(user_id):
    """更新用户"""
    user = User.query.get_or_404(user_id)
    data = request.get_json()
    
    # 不允许修改admin用户的用户名
    if user.username == 'admin' and data.get('username') != 'admin':
        return jsonify({'code': 1, 'msg': '不能修改管理员用户名'})
    
    username = data.get('username', '').strip()
    if username and username != user.username:
        if User.query.filter_by(username=username).first():
            return jsonify({'code': 1, 'msg': '用户名已存在'})
        user.username = username
    
    email = data.get('email', '').strip()
    if email and email != user.email:
        if User.query.filter_by(email=email).first():
            return jsonify({'code': 1, 'msg': '邮箱已被使用'})
        user.email = email
    
    if 'realname' in data:
        user.realname = data['realname']
    if 'phone' in data:
        user.phone = data['phone']
    if 'role_id' in data:
        # 不允许修改admin用户的角色
        if user.username != 'admin':
            user.role_id = data['role_id']
    if 'is_active' in data:
        # 不允许禁用admin用户
        if user.username != 'admin':
            user.is_active = data['is_active']
    
    # 如果提供了新密码，则更新密码
    password = data.get('password', '')
    if password:
        if len(password) < 6:
            return jsonify({'code': 1, 'msg': '密码长度不能少于6位'})
        user.set_password(password)
    
    db.session.commit()
    
    return jsonify({'code': 0, 'msg': '更新成功', 'data': user.to_dict()})


@admin_bp.route('/api/users/<int:user_id>', methods=['DELETE'])
@login_required
@admin_required
def delete_user(user_id):
    """删除用户"""
    user = User.query.get_or_404(user_id)
    
    # 不允许删除admin用户
    if user.username == 'admin':
        return jsonify({'code': 1, 'msg': '不能删除管理员账户'})
    
    # 不允许删除自己
    if user.id == current_user.id:
        return jsonify({'code': 1, 'msg': '不能删除当前登录账户'})
    
    db.session.delete(user)
    db.session.commit()
    
    return jsonify({'code': 0, 'msg': '删除成功'})


# ==================== 角色管理API ====================

@admin_bp.route('/api/roles', methods=['GET'])
@login_required
@admin_required
def get_roles():
    """获取角色列表"""
    page = request.args.get('page', 1, type=int)
    limit = request.args.get('limit', 10, type=int)
    
    pagination = Role.query.order_by(Role.id).paginate(
        page=page, per_page=limit, error_out=False
    )
    
    roles = [role.to_dict() for role in pagination.items]
    
    return jsonify({
        'code': 0,
        'msg': 'success',
        'count': pagination.total,
        'data': roles
    })


@admin_bp.route('/api/roles/all', methods=['GET'])
@login_required
def get_all_roles():
    """获取所有角色（用于下拉选择）"""
    roles = Role.query.all()
    return jsonify({
        'code': 0,
        'data': [role.to_dict() for role in roles]
    })


@admin_bp.route('/api/roles', methods=['POST'])
@login_required
@admin_required
def create_role():
    """创建角色"""
    data = request.get_json()
    
    name = data.get('name', '').strip()
    description = data.get('description', '').strip()
    permissions = data.get('permissions', '')
    
    if not name:
        return jsonify({'code': 1, 'msg': '角色名称不能为空'})
    
    if Role.query.filter_by(name=name).first():
        return jsonify({'code': 1, 'msg': '角色名称已存在'})
    
    role = Role(name=name, description=description, permissions=permissions)
    db.session.add(role)
    db.session.commit()
    
    return jsonify({'code': 0, 'msg': '创建成功', 'data': role.to_dict()})


@admin_bp.route('/api/roles/<int:role_id>', methods=['PUT'])
@login_required
@admin_required
def update_role(role_id):
    """更新角色"""
    role = Role.query.get_or_404(role_id)
    data = request.get_json()
    
    # 不允许修改admin和user角色的名称
    if role.name in ['admin', 'user'] and data.get('name') != role.name:
        return jsonify({'code': 1, 'msg': '不能修改系统内置角色名称'})
    
    name = data.get('name', '').strip()
    if name and name != role.name:
        if Role.query.filter_by(name=name).first():
            return jsonify({'code': 1, 'msg': '角色名称已存在'})
        role.name = name
    
    if 'description' in data:
        role.description = data['description']
    if 'permissions' in data:
        role.permissions = data['permissions']
    
    db.session.commit()
    
    return jsonify({'code': 0, 'msg': '更新成功', 'data': role.to_dict()})


@admin_bp.route('/api/roles/<int:role_id>', methods=['DELETE'])
@login_required
@admin_required
def delete_role(role_id):
    """删除角色"""
    role = Role.query.get_or_404(role_id)
    
    # 不允许删除系统内置角色
    if role.name in ['admin', 'user']:
        return jsonify({'code': 1, 'msg': '不能删除系统内置角色'})
    
    # 检查是否有用户使用此角色
    if role.users.count() > 0:
        return jsonify({'code': 1, 'msg': '该角色下还有用户，无法删除'})
    
    db.session.delete(role)
    db.session.commit()
    
    return jsonify({'code': 0, 'msg': '删除成功'})


# ==================== 系统设置API ====================

@admin_bp.route('/api/settings', methods=['GET'])
@login_required
@admin_required
def get_settings():
    """获取系统设置"""
    settings = SystemSetting.query.all()
    return jsonify({
        'code': 0,
        'data': [s.to_dict() for s in settings]
    })


@admin_bp.route('/api/settings', methods=['POST'])
@login_required
@admin_required
def update_settings():
    """更新系统设置"""
    data = request.get_json()
    
    for key, value in data.items():
        SystemSetting.set_setting(key, value)
    
    return jsonify({'code': 0, 'msg': '保存成功'})


@admin_bp.route('/api/settings/upload_logo', methods=['POST'])
@login_required
@admin_required
def upload_logo():
    """上传LOGO"""
    if 'file' not in request.files:
        return jsonify({'code': 1, 'msg': '没有上传文件'})
    
    file = request.files['file']
    if file.filename == '':
        return jsonify({'code': 1, 'msg': '没有选择文件'})
    
    # 检查文件类型
    allowed_extensions = {'png', 'jpg', 'jpeg', 'gif', 'svg'}
    ext = file.filename.rsplit('.', 1)[1].lower() if '.' in file.filename else ''
    if ext not in allowed_extensions:
        return jsonify({'code': 1, 'msg': '不支持的文件格式'})
    
    # 保存文件
    filename = secure_filename(f'logo.{ext}')
    upload_folder = os.path.join(current_app.static_folder, 'uploads')
    os.makedirs(upload_folder, exist_ok=True)
    
    filepath = os.path.join(upload_folder, filename)
    file.save(filepath)
    
    # 更新系统设置
    logo_url = f'/static/uploads/{filename}'
    SystemSetting.set_setting('app_logo', logo_url)
    
    return jsonify({'code': 0, 'msg': '上传成功', 'data': {'url': logo_url}})


# ==================== 数据采集管理 ====================

@admin_bp.route('/collect')
@login_required
@admin_required
def collect_page():
    """数据采集管理页面"""
    return render_template('admin/collect.html')


@admin_bp.route('/api/collect/search', methods=['POST'])
@login_required
@admin_required
def collect_search():
    """搜索采集数据"""
    data = request.get_json()
    keyword = data.get('keyword', '').strip()
    pages = data.get('pages', 1)
    
    if not keyword:
        return jsonify({'code': 1, 'msg': '请输入搜索关键词'})
    
    try:
        # 调用爬虫获取数据
        results = fetch_news(keyword, pages=pages)
        
        return jsonify({
            'code': 0,
            'msg': 'success',
            'count': len(results),
            'keyword': keyword,
            'data': results
        })
    except Exception as e:
        return jsonify({'code': 1, 'msg': f'采集失败: {str(e)}'})


@admin_bp.route('/api/collect/xinhua', methods=['POST'])
@login_required
@admin_required
def collect_xinhua():
    """从新华网四川要闻采集数据"""
    data = request.get_json()
    keyword = data.get('keyword', '').strip()
    
    try:
        # 调用新华爬虫获取数据
        results = fetch_xinhua_news(keyword if keyword else None)
        
        return jsonify({
            'code': 0,
            'msg': 'success',
            'count': len(results),
            'keyword': keyword,
            'source': '新华网四川',
            'data': results
        })
    except Exception as e:
        return jsonify({'code': 1, 'msg': f'新华网采集失败: {str(e)}'})


@admin_bp.route('/api/collect/deep', methods=['POST'])
@login_required
@admin_required
def collect_deep():
    """深度采集单条数据 - 通过原地址进入详细页面采集详细内容"""
    from datetime import datetime
    import requests
    from bs4 import BeautifulSoup
    import re
    
    data = request.get_json()
    url = data.get('url', '').strip()
    
    if not url:
        return jsonify({'code': 1, 'msg': '缺少URL参数'})
    
    try:
        # 发送请求获取页面内容
        headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
            'Accept-Language': 'zh-CN,zh;q=0.9,en;q=0.8',
            'Connection': 'keep-alive'
        }
        response = requests.get(url, headers=headers, timeout=20, allow_redirects=True)
        response.encoding = response.apparent_encoding or 'utf-8'
        
        # 解析页面内容
        soup = BeautifulSoup(response.text, 'html.parser')
        
        # 提取页面标题
        page_title = ''
        title_elem = soup.find('title')
        if title_elem:
            page_title = title_elem.get_text(strip=True)
        
        # 尝试从h1标签获取更精确的标题
        h1_elem = soup.find('h1')
        if h1_elem:
            page_title = h1_elem.get_text(strip=True) or page_title
        
        # 移除脚本、样式和无关元素
        for elem in soup(['script', 'style', 'nav', 'header', 'footer', 'aside', 
                          'iframe', 'noscript', 'form', 'button', 'input']):
            elem.decompose()
        
        # 移除注释
        for comment in soup.find_all(string=lambda text: isinstance(text, type(soup.new_string('')))):
            if isinstance(comment, type(soup.new_string(''))) and comment.parent and comment.parent.name is None:
                comment.extract()
        
        # 尝试提取正文内容
        content = ''
        
        # 常见的正文容器选择器（按优先级排序）
        content_selectors = [
            # 新闻网站常用
            '.article-content', '.news-content', '.post-content',
            '.article-body', '.news-body', '.post-body',
            '#article-content', '#news-content', '#post-content',
            # 通用选择器
            'article', '.article', '#article',
            '.content', '#content', '.main-content', '#main-content',
            '.entry-content', '.text-content', '.body-content',
            # 百度百家号等
            '.index-module_articleWrap', '.article-holder',
            # 微信公众号
            '#js_content', '.rich_media_content',
            # 其他
            '[itemprop="articleBody"]', '[role="main"]',
            '.detail-content', '.news-detail', '.article-detail'
        ]
        
        for selector in content_selectors:
            content_elem = soup.select_one(selector)
            if content_elem:
                # 获取所有段落文本
                paragraphs = content_elem.find_all(['p', 'div', 'span'])
                texts = []
                for p in paragraphs:
                    text = p.get_text(strip=True)
                    # 过滤太短的文本和广告相关文本
                    if len(text) > 15 and not re.search(r'(广告|推荐阅读|相关文章|点击查看|分享到)', text):
                        texts.append(text)
                if texts:
                    content = '\n\n'.join(texts)
                    break
        
        # 如果没找到，尝试获取body中的主要文本
        if not content:
            body = soup.find('body')
            if body:
                paragraphs = body.find_all('p')
                texts = []
                for p in paragraphs:
                    text = p.get_text(strip=True)
                    if len(text) > 25:
                        texts.append(text)
                content = '\n\n'.join(texts[:30])  # 限制段落数量
        
        # 清理内容中的多余空白
        if content:
            content = re.sub(r'\n{3,}', '\n\n', content)
            content = re.sub(r' {2,}', ' ', content)
        
        if not content:
            content = '无法提取正文内容，请直接访问原文链接查看。'
        
        return jsonify({
            'code': 0,
            'msg': '深度采集成功',
            'data': {
                'title': page_title,
                'content': content[:8000],  # 限制内容长度
                'url': response.url,  # 返回最终URL（可能有重定向）
                'collected_at': datetime.utcnow().strftime('%Y-%m-%d %H:%M:%S')
            }
        })
    except requests.Timeout:
        return jsonify({'code': 1, 'msg': '请求超时，目标网站响应过慢'})
    except requests.RequestException as e:
        return jsonify({'code': 1, 'msg': f'请求失败: {str(e)}'})
    except Exception as e:
        return jsonify({'code': 1, 'msg': f'深度采集失败: {str(e)}'})


@admin_bp.route('/api/collect/save', methods=['POST'])
@login_required
@admin_required
def collect_save():
    """保存采集数据到数据库"""
    data = request.get_json()
    items = data.get('items', [])
    keyword = data.get('keyword', '')
    
    if not items:
        return jsonify({'code': 1, 'msg': '没有要保存的数据'})
    
    saved_count = 0
    skipped_count = 0
    
    for item in items:
        # 检查是否已存在（根据URL去重）
        existing = CollectedData.query.filter_by(url=item.get('url')).first()
        if existing:
            skipped_count += 1
            continue
        
        collected = CollectedData(
            title=item.get('title', ''),
            summary=item.get('summary', ''),
            content=item.get('content', ''),
            cover=item.get('cover', ''),
            url=item.get('url', ''),
            source=item.get('source', ''),
            keyword=keyword,
            is_deep_collected=item.get('is_deep_collected', False),
            user_id=current_user.id
        )
        
        if item.get('is_deep_collected'):
            from datetime import datetime
            collected.deep_collected_at = datetime.utcnow()
        
        db.session.add(collected)
        saved_count += 1
    
    db.session.commit()
    
    return jsonify({
        'code': 0,
        'msg': f'保存成功！新增 {saved_count} 条，跳过 {skipped_count} 条重复数据'
    })


@admin_bp.route('/api/collect/list', methods=['GET'])
@login_required
@admin_required
def collect_list():
    """获取已保存的采集数据列表"""
    page = request.args.get('page', 1, type=int)
    limit = request.args.get('limit', 10, type=int)
    keyword = request.args.get('keyword', '')
    
    query = CollectedData.query
    if keyword:
        query = query.filter(
            db.or_(
                CollectedData.title.like(f'%{keyword}%'),
                CollectedData.keyword.like(f'%{keyword}%')
            )
        )
    
    pagination = query.order_by(CollectedData.created_at.desc()).paginate(
        page=page, per_page=limit, error_out=False
    )
    
    return jsonify({
        'code': 0,
        'msg': 'success',
        'count': pagination.total,
        'data': [item.to_dict() for item in pagination.items]
    })


@admin_bp.route('/api/collect/<int:item_id>', methods=['DELETE'])
@login_required
@admin_required
def collect_delete(item_id):
    """删除采集数据"""
    item = CollectedData.query.get_or_404(item_id)
    db.session.delete(item)
    db.session.commit()
    return jsonify({'code': 0, 'msg': '删除成功'})


@admin_bp.route('/api/collect/batch_delete', methods=['POST'])
@login_required
@admin_required
def collect_batch_delete():
    """批量删除采集数据"""
    data = request.get_json()
    ids = data.get('ids', [])
    
    if not ids:
        return jsonify({'code': 1, 'msg': '请选择要删除的数据'})
    
    CollectedData.query.filter(CollectedData.id.in_(ids)).delete(synchronize_session=False)
    db.session.commit()
    
    return jsonify({'code': 0, 'msg': f'成功删除 {len(ids)} 条数据'})


# ==================== 采集规则库管理 ====================

@admin_bp.route('/crawl_rules')
@login_required
@admin_required
def crawl_rules_page():
    """采集规则库页面"""
    return render_template('admin/crawl_rules.html')


@admin_bp.route('/api/crawl_rules/init', methods=['POST'])
@login_required
@admin_required
def init_crawl_rules():
    """初始化默认采集规则"""
    try:
        added_count = CrawlRule.init_default_rules()
        if added_count > 0:
            return jsonify({'code': 0, 'msg': f'成功添加 {added_count} 条默认规则'})
        else:
            return jsonify({'code': 0, 'msg': '默认规则已存在，无需重复添加'})
    except Exception as e:
        return jsonify({'code': 1, 'msg': f'初始化失败: {str(e)}'})


@admin_bp.route('/api/crawl_rules', methods=['GET'])
@login_required
@admin_required
def crawl_rules_list():
    """获取采集规则列表"""
    page = request.args.get('page', 1, type=int)
    limit = request.args.get('limit', 10, type=int)
    keyword = request.args.get('keyword', '')
    
    query = CrawlRule.query
    if keyword:
        query = query.filter(
            db.or_(
                CrawlRule.name.like(f'%{keyword}%'),
                CrawlRule.site_name.like(f'%{keyword}%'),
                CrawlRule.site_url.like(f'%{keyword}%')
            )
        )
    
    pagination = query.order_by(CrawlRule.created_at.desc()).paginate(
        page=page, per_page=limit, error_out=False
    )
    
    return jsonify({
        'code': 0,
        'msg': 'success',
        'count': pagination.total,
        'data': [rule.to_dict() for rule in pagination.items]
    })


@admin_bp.route('/api/crawl_rules', methods=['POST'])
@login_required
@admin_required
def crawl_rules_create():
    """创建采集规则"""
    import json
    data = request.get_json()
    
    # 验证必填字段
    if not data.get('name'):
        return jsonify({'code': 1, 'msg': '规则名称不能为空'})
    if not data.get('site_name'):
        return jsonify({'code': 1, 'msg': '站点名称不能为空'})
    if not data.get('site_url'):
        return jsonify({'code': 1, 'msg': '站点URL不能为空'})
    
    # 处理request_headers
    headers = data.get('request_headers', {})
    if isinstance(headers, dict):
        headers = json.dumps(headers, ensure_ascii=False)
    
    rule = CrawlRule(
        name=data.get('name'),
        site_name=data.get('site_name'),
        site_url=data.get('site_url'),
        title_xpath=data.get('title_xpath', ''),
        content_xpath=data.get('content_xpath', ''),
        list_xpath=data.get('list_xpath', ''),
        link_xpath=data.get('link_xpath', ''),
        summary_xpath=data.get('summary_xpath', ''),
        cover_xpath=data.get('cover_xpath', ''),
        date_xpath=data.get('date_xpath', ''),
        request_headers=headers,
        encoding=data.get('encoding', 'utf-8'),
        is_enabled=data.get('is_enabled', True),
        description=data.get('description', ''),
        user_id=current_user.id
    )
    
    db.session.add(rule)
    db.session.commit()
    
    return jsonify({
        'code': 0,
        'msg': '创建成功',
        'data': rule.to_dict()
    })


@admin_bp.route('/api/crawl_rules/<int:rule_id>', methods=['GET'])
@login_required
@admin_required
def crawl_rules_get(rule_id):
    """获取单个采集规则"""
    rule = CrawlRule.query.get_or_404(rule_id)
    return jsonify({
        'code': 0,
        'data': rule.to_dict()
    })


@admin_bp.route('/api/crawl_rules/<int:rule_id>', methods=['PUT'])
@login_required
@admin_required
def crawl_rules_update(rule_id):
    """更新采集规则"""
    import json
    rule = CrawlRule.query.get_or_404(rule_id)
    data = request.get_json()
    
    # 更新字段
    if 'name' in data:
        rule.name = data['name']
    if 'site_name' in data:
        rule.site_name = data['site_name']
    if 'site_url' in data:
        rule.site_url = data['site_url']
    if 'title_xpath' in data:
        rule.title_xpath = data['title_xpath']
    if 'content_xpath' in data:
        rule.content_xpath = data['content_xpath']
    if 'list_xpath' in data:
        rule.list_xpath = data['list_xpath']
    if 'link_xpath' in data:
        rule.link_xpath = data['link_xpath']
    if 'summary_xpath' in data:
        rule.summary_xpath = data['summary_xpath']
    if 'cover_xpath' in data:
        rule.cover_xpath = data['cover_xpath']
    if 'date_xpath' in data:
        rule.date_xpath = data['date_xpath']
    if 'request_headers' in data:
        headers = data['request_headers']
        if isinstance(headers, dict):
            headers = json.dumps(headers, ensure_ascii=False)
        rule.request_headers = headers
    if 'encoding' in data:
        rule.encoding = data['encoding']
    if 'is_enabled' in data:
        rule.is_enabled = data['is_enabled']
    if 'description' in data:
        rule.description = data['description']
    
    db.session.commit()
    
    return jsonify({
        'code': 0,
        'msg': '更新成功',
        'data': rule.to_dict()
    })


@admin_bp.route('/api/crawl_rules/<int:rule_id>', methods=['DELETE'])
@login_required
@admin_required
def crawl_rules_delete(rule_id):
    """删除采集规则"""
    rule = CrawlRule.query.get_or_404(rule_id)
    db.session.delete(rule)
    db.session.commit()
    return jsonify({'code': 0, 'msg': '删除成功'})


@admin_bp.route('/api/crawl_rules/<int:rule_id>/toggle', methods=['POST'])
@login_required
@admin_required
def crawl_rules_toggle(rule_id):
    """切换采集规则启用状态"""
    rule = CrawlRule.query.get_or_404(rule_id)
    rule.is_enabled = not rule.is_enabled
    db.session.commit()
    
    status = '启用' if rule.is_enabled else '禁用'
    return jsonify({
        'code': 0,
        'msg': f'规则已{status}',
        'data': {'is_enabled': rule.is_enabled}
    })


@admin_bp.route('/api/crawl_rules/test', methods=['POST'])
@login_required
@admin_required
def crawl_rules_test():
    """测试采集规则"""
    import requests
    from lxml import etree
    import json
    
    data = request.get_json()
    site_url = data.get('site_url', '')
    title_xpath = data.get('title_xpath', '')
    encoding = data.get('encoding', 'utf-8')
    headers_config = data.get('request_headers', {})
    
    if not site_url:
        return jsonify({'code': 1, 'msg': '请输入站点URL'})
    
    try:
        # 构建请求头
        headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36'
        }
        if isinstance(headers_config, dict):
            headers.update(headers_config)
        
        # 发送请求
        response = requests.get(site_url, headers=headers, timeout=10)
        response.encoding = encoding
        
        # 解析HTML
        html = etree.HTML(response.text)
        
        result = {
            'status': response.status_code,
            'encoding': encoding,
            'content_length': len(response.text)
        }
        
        # 测试XPath
        if title_xpath:
            titles = html.xpath(title_xpath)
            result['title_test'] = {
                'xpath': title_xpath,
                'count': len(titles),
                'samples': [str(t)[:100] if hasattr(t, '__str__') else t.text[:100] if hasattr(t, 'text') and t.text else str(t)[:100] for t in titles[:5]]
            }
        
        return jsonify({
            'code': 0,
            'msg': '测试成功',
            'data': result
        })
        
    except requests.RequestException as e:
        return jsonify({'code': 1, 'msg': f'请求失败: {str(e)}'})
    except Exception as e:
        return jsonify({'code': 1, 'msg': f'测试失败: {str(e)}'})


# ==================== AI引擎管理 ====================

@admin_bp.route('/ai_engines')
@login_required
@admin_required
def ai_engines_page():
    """AI引擎管理页面"""
    return render_template('admin/ai_engines.html')


@admin_bp.route('/api/ai_engines', methods=['GET'])
@login_required
def get_ai_engines():
    """获取AI引擎列表"""
    engines = AIEngine.query.order_by(AIEngine.is_default.desc(), AIEngine.created_at.desc()).all()
    return jsonify({
        'code': 0,
        'data': [e.to_safe_dict() for e in engines]
    })


@admin_bp.route('/api/ai_engines', methods=['POST'])
@login_required
@admin_required
def create_ai_engine():
    """创建AI引擎"""
    data = request.get_json()
    
    # 验证必填字段
    required_fields = ['name', 'provider', 'api_url', 'api_key', 'model_name']
    for field in required_fields:
        if not data.get(field):
            return jsonify({'code': 1, 'msg': f'请填写{field}'})
    
    # 如果设为默认，取消其他默认
    if data.get('is_default'):
        AIEngine.query.update({'is_default': False})
    
    engine = AIEngine(
        name=data['name'],
        provider=data['provider'],
        api_url=data['api_url'],
        api_key=data['api_key'],
        model_name=data['model_name'],
        max_tokens=data.get('max_tokens', 2000),
        temperature=data.get('temperature', 0.7),
        timeout=data.get('timeout', 60),
        is_enabled=data.get('is_enabled', True),
        is_default=data.get('is_default', False),
        description=data.get('description', ''),
        icon=data.get('icon', 'layui-icon-fire'),
        color=data.get('color', '#667eea'),
        user_id=current_user.id
    )
    
    db.session.add(engine)
    db.session.commit()
    
    return jsonify({
        'code': 0,
        'msg': '创建成功',
        'data': engine.to_safe_dict()
    })


@admin_bp.route('/api/ai_engines/<int:engine_id>', methods=['GET'])
@login_required
def get_ai_engine(engine_id):
    """获取单个AI引擎详情"""
    engine = AIEngine.query.get_or_404(engine_id)
    return jsonify({
        'code': 0,
        'data': engine.to_dict()
    })


@admin_bp.route('/api/ai_engines/<int:engine_id>', methods=['PUT'])
@login_required
@admin_required
def update_ai_engine(engine_id):
    """更新AI引擎"""
    engine = AIEngine.query.get_or_404(engine_id)
    data = request.get_json()
    
    # 如果设为默认，取消其他默认
    if data.get('is_default') and not engine.is_default:
        AIEngine.query.filter(AIEngine.id != engine_id).update({'is_default': False})
    
    engine.name = data.get('name', engine.name)
    engine.provider = data.get('provider', engine.provider)
    engine.api_url = data.get('api_url', engine.api_url)
    if data.get('api_key'):
        engine.api_key = data['api_key']
    engine.model_name = data.get('model_name', engine.model_name)
    engine.max_tokens = data.get('max_tokens', engine.max_tokens)
    engine.temperature = data.get('temperature', engine.temperature)
    engine.timeout = data.get('timeout', engine.timeout)
    engine.is_enabled = data.get('is_enabled', engine.is_enabled)
    engine.is_default = data.get('is_default', engine.is_default)
    engine.description = data.get('description', engine.description)
    engine.icon = data.get('icon', engine.icon)
    engine.color = data.get('color', engine.color)
    
    db.session.commit()
    
    return jsonify({
        'code': 0,
        'msg': '更新成功',
        'data': engine.to_safe_dict()
    })


@admin_bp.route('/api/ai_engines/<int:engine_id>', methods=['DELETE'])
@login_required
@admin_required
def delete_ai_engine(engine_id):
    """删除AI引擎"""
    engine = AIEngine.query.get_or_404(engine_id)
    db.session.delete(engine)
    db.session.commit()
    
    return jsonify({'code': 0, 'msg': '删除成功'})


@admin_bp.route('/api/ai_engines/<int:engine_id>/toggle', methods=['POST'])
@login_required
@admin_required
def toggle_ai_engine(engine_id):
    """切换AI引擎启用状态"""
    engine = AIEngine.query.get_or_404(engine_id)
    engine.is_enabled = not engine.is_enabled
    db.session.commit()
    
    return jsonify({
        'code': 0,
        'msg': '已' + ('启用' if engine.is_enabled else '禁用'),
        'data': {'is_enabled': engine.is_enabled}
    })


@admin_bp.route('/api/ai_engines/<int:engine_id>/set_default', methods=['POST'])
@login_required
@admin_required
def set_default_ai_engine(engine_id):
    """设置默认AI引擎"""
    # 取消所有默认
    AIEngine.query.update({'is_default': False})
    
    # 设置新默认
    engine = AIEngine.query.get_or_404(engine_id)
    engine.is_default = True
    db.session.commit()
    
    return jsonify({
        'code': 0,
        'msg': f'已将 {engine.name} 设为默认引擎'
    })


@admin_bp.route('/api/ai_engines/<int:engine_id>/test', methods=['POST'])
@login_required
def test_ai_engine(engine_id):
    """测试AI引擎连接"""
    import requests
    
    engine = AIEngine.query.get_or_404(engine_id)
    
    try:
        # 构建测试请求
        headers = {
            'Content-Type': 'application/json',
            'Authorization': f'Bearer {engine.api_key}'
        }
        
        payload = {
            'model': engine.model_name,
            'messages': [
                {'role': 'user', 'content': '你好，请简单回复"连接成功"'}
            ],
            'max_tokens': 50,
            'temperature': 0.7
        }
        
        response = requests.post(
            engine.api_url,
            headers=headers,
            json=payload,
            timeout=engine.timeout
        )
        
        if response.status_code == 200:
            result = response.json()
            # 尝试提取回复内容
            reply = ''
            if 'choices' in result and len(result['choices']) > 0:
                choice = result['choices'][0]
                if 'message' in choice:
                    reply = choice['message'].get('content', '')
                elif 'text' in choice:
                    reply = choice['text']
            
            return jsonify({
                'code': 0,
                'msg': '连接成功',
                'data': {
                    'reply': reply[:200] if reply else '无回复内容',
                    'status_code': response.status_code
                }
            })
        else:
            return jsonify({
                'code': 1,
                'msg': f'API返回错误: {response.status_code}',
                'data': {'response': response.text[:500]}
            })
            
    except requests.Timeout:
        return jsonify({'code': 1, 'msg': '请求超时，请检查API地址或增加超时时间'})
    except requests.RequestException as e:
        return jsonify({'code': 1, 'msg': f'请求失败: {str(e)}'})
    except Exception as e:
        return jsonify({'code': 1, 'msg': f'测试失败: {str(e)}'})


@admin_bp.route('/api/ai_engines/<int:engine_id>/chat', methods=['POST'])
@login_required
def chat_with_ai_engine(engine_id):
    """与AI引擎进行对话"""
    import requests
    from datetime import datetime
    
    engine = AIEngine.query.get_or_404(engine_id)
    
    if not engine.is_enabled:
        return jsonify({'code': 1, 'msg': '该引擎已禁用'})
    
    data = request.get_json()
    message = data.get('message', '')
    history = data.get('history', [])
    
    if not message:
        return jsonify({'code': 1, 'msg': '消息不能为空'})
    
    try:
        # 构建消息列表
        messages = []
        
        # 添加系统提示
        messages.append({
            'role': 'system',
            'content': '你是一个智能助手，请用中文回答用户的问题。回答要简洁、准确、有帮助。'
        })
        
        # 添加历史消息
        for h in history[-10:]:  # 只保留最近10条
            messages.append({
                'role': h.get('role', 'user'),
                'content': h.get('content', '')
            })
        
        # 添加当前消息
        messages.append({
            'role': 'user',
            'content': message
        })
        
        # 构建请求
        headers = {
            'Content-Type': 'application/json',
            'Authorization': f'Bearer {engine.api_key}'
        }
        
        payload = {
            'model': engine.model_name,
            'messages': messages,
            'max_tokens': engine.max_tokens,
            'temperature': engine.temperature
        }
        
        response = requests.post(
            engine.api_url,
            headers=headers,
            json=payload,
            timeout=engine.timeout
        )
        
        if response.status_code == 200:
            result = response.json()
            
            # 提取回复内容
            reply = ''
            if 'choices' in result and len(result['choices']) > 0:
                choice = result['choices'][0]
                if 'message' in choice:
                    reply = choice['message'].get('content', '')
                elif 'text' in choice:
                    reply = choice['text']
            
            # 更新调用统计
            engine.call_count = (engine.call_count or 0) + 1
            engine.last_used_at = datetime.utcnow()
            db.session.commit()
            
            return jsonify({
                'code': 0,
                'msg': 'success',
                'data': {
                    'reply': reply.strip() if reply else '抱歉，我没有理解你的问题。'
                }
            })
        else:
            error_msg = f'API返回错误: {response.status_code}'
            try:
                error_data = response.json()
                if 'error' in error_data:
                    error_msg = error_data['error'].get('message', error_msg)
            except:
                pass
            return jsonify({'code': 1, 'msg': error_msg})
            
    except requests.Timeout:
        return jsonify({'code': 1, 'msg': '请求超时，请稍后重试'})
    except requests.RequestException as e:
        return jsonify({'code': 1, 'msg': f'网络请求失败: {str(e)}'})
    except Exception as e:
        return jsonify({'code': 1, 'msg': f'对话失败: {str(e)}'})


# ==================== 爬虫管理 ====================

@admin_bp.route('/crawlers')
@login_required
@admin_required
def crawlers_page():
    """爬虫管理页面"""
    return render_template('admin/crawlers.html')


@admin_bp.route('/api/crawlers', methods=['GET'])
@login_required
def get_crawlers():
    """获取爬虫配置列表"""
    crawlers = CrawlerConfig.query.order_by(CrawlerConfig.priority.desc(), CrawlerConfig.created_at.desc()).all()
    return jsonify({
        'code': 0,
        'data': [c.to_dict() for c in crawlers]
    })


@admin_bp.route('/api/crawlers/enabled', methods=['GET'])
@login_required
def get_enabled_crawlers():
    """获取已启用的爬虫列表（用于数据采集页面选择）"""
    crawlers = CrawlerConfig.query.filter_by(is_enabled=True).order_by(CrawlerConfig.priority.desc()).all()
    return jsonify({
        'code': 0,
        'data': [{'id': c.id, 'name': c.name, 'crawler_type': c.crawler_type, 'icon': c.icon, 'color': c.color, 'is_default': c.is_default} for c in crawlers]
    })


@admin_bp.route('/api/crawlers', methods=['POST'])
@login_required
@admin_required
def create_crawler():
    """创建爬虫配置"""
    import json
    data = request.get_json()
    
    # 验证必填字段
    if not data.get('name'):
        return jsonify({'code': 1, 'msg': '爬虫名称不能为空'})
    if not data.get('crawler_type'):
        return jsonify({'code': 1, 'msg': '爬虫类型不能为空'})
    
    # 检查名称是否重复
    if CrawlerConfig.query.filter_by(name=data['name']).first():
        return jsonify({'code': 1, 'msg': '爬虫名称已存在'})
    
    # 如果设为默认，取消其他默认
    if data.get('is_default'):
        CrawlerConfig.query.update({'is_default': False})
    
    # 处理请求头
    headers = data.get('request_headers', {})
    if isinstance(headers, dict):
        headers = json.dumps(headers, ensure_ascii=False)
    
    crawler = CrawlerConfig(
        name=data['name'],
        crawler_type=data['crawler_type'],
        description=data.get('description', ''),
        base_url=data.get('base_url', ''),
        search_url=data.get('search_url', ''),
        encoding=data.get('encoding', 'utf-8'),
        request_headers=headers,
        request_timeout=data.get('request_timeout', 15),
        request_delay=data.get('request_delay', 1.0),
        max_retries=data.get('max_retries', 3),
        list_selector=data.get('list_selector', ''),
        title_selector=data.get('title_selector', ''),
        link_selector=data.get('link_selector', ''),
        summary_selector=data.get('summary_selector', ''),
        cover_selector=data.get('cover_selector', ''),
        source_selector=data.get('source_selector', ''),
        date_selector=data.get('date_selector', ''),
        content_selector=data.get('content_selector', ''),
        is_enabled=data.get('is_enabled', True),
        is_default=data.get('is_default', False),
        priority=data.get('priority', 0),
        icon=data.get('icon', 'layui-icon-website'),
        color=data.get('color', '#1E9FFF'),
        user_id=current_user.id
    )
    
    db.session.add(crawler)
    db.session.commit()
    
    return jsonify({
        'code': 0,
        'msg': '创建成功',
        'data': crawler.to_dict()
    })


@admin_bp.route('/api/crawlers/<int:crawler_id>', methods=['GET'])
@login_required
def get_crawler(crawler_id):
    """获取单个爬虫配置"""
    crawler = CrawlerConfig.query.get_or_404(crawler_id)
    return jsonify({
        'code': 0,
        'data': crawler.to_dict()
    })


@admin_bp.route('/api/crawlers/<int:crawler_id>', methods=['PUT'])
@login_required
@admin_required
def update_crawler(crawler_id):
    """更新爬虫配置"""
    import json
    crawler = CrawlerConfig.query.get_or_404(crawler_id)
    data = request.get_json()
    
    # 检查名称是否重复
    if data.get('name') and data['name'] != crawler.name:
        if CrawlerConfig.query.filter_by(name=data['name']).first():
            return jsonify({'code': 1, 'msg': '爬虫名称已存在'})
    
    # 如果设为默认，取消其他默认
    if data.get('is_default') and not crawler.is_default:
        CrawlerConfig.query.filter(CrawlerConfig.id != crawler_id).update({'is_default': False})
    
    # 更新字段
    if 'name' in data:
        crawler.name = data['name']
    if 'crawler_type' in data:
        crawler.crawler_type = data['crawler_type']
    if 'description' in data:
        crawler.description = data['description']
    if 'base_url' in data:
        crawler.base_url = data['base_url']
    if 'search_url' in data:
        crawler.search_url = data['search_url']
    if 'encoding' in data:
        crawler.encoding = data['encoding']
    if 'request_headers' in data:
        headers = data['request_headers']
        if isinstance(headers, dict):
            headers = json.dumps(headers, ensure_ascii=False)
        crawler.request_headers = headers
    if 'request_timeout' in data:
        crawler.request_timeout = data['request_timeout']
    if 'request_delay' in data:
        crawler.request_delay = data['request_delay']
    if 'max_retries' in data:
        crawler.max_retries = data['max_retries']
    if 'list_selector' in data:
        crawler.list_selector = data['list_selector']
    if 'title_selector' in data:
        crawler.title_selector = data['title_selector']
    if 'link_selector' in data:
        crawler.link_selector = data['link_selector']
    if 'summary_selector' in data:
        crawler.summary_selector = data['summary_selector']
    if 'cover_selector' in data:
        crawler.cover_selector = data['cover_selector']
    if 'source_selector' in data:
        crawler.source_selector = data['source_selector']
    if 'date_selector' in data:
        crawler.date_selector = data['date_selector']
    if 'content_selector' in data:
        crawler.content_selector = data['content_selector']
    if 'is_enabled' in data:
        crawler.is_enabled = data['is_enabled']
    if 'is_default' in data:
        crawler.is_default = data['is_default']
    if 'priority' in data:
        crawler.priority = data['priority']
    if 'icon' in data:
        crawler.icon = data['icon']
    if 'color' in data:
        crawler.color = data['color']
    
    db.session.commit()
    
    return jsonify({
        'code': 0,
        'msg': '更新成功',
        'data': crawler.to_dict()
    })


@admin_bp.route('/api/crawlers/<int:crawler_id>', methods=['DELETE'])
@login_required
@admin_required
def delete_crawler(crawler_id):
    """删除爬虫配置"""
    crawler = CrawlerConfig.query.get_or_404(crawler_id)
    db.session.delete(crawler)
    db.session.commit()
    
    return jsonify({'code': 0, 'msg': '删除成功'})


@admin_bp.route('/api/crawlers/<int:crawler_id>/toggle', methods=['POST'])
@login_required
@admin_required
def toggle_crawler(crawler_id):
    """切换爬虫启用状态"""
    crawler = CrawlerConfig.query.get_or_404(crawler_id)
    crawler.is_enabled = not crawler.is_enabled
    db.session.commit()
    
    return jsonify({
        'code': 0,
        'msg': '已' + ('启用' if crawler.is_enabled else '禁用'),
        'data': {'is_enabled': crawler.is_enabled}
    })


@admin_bp.route('/api/crawlers/<int:crawler_id>/set_default', methods=['POST'])
@login_required
@admin_required
def set_default_crawler(crawler_id):
    """设置默认爬虫"""
    # 取消所有默认
    CrawlerConfig.query.update({'is_default': False})
    
    # 设置新默认
    crawler = CrawlerConfig.query.get_or_404(crawler_id)
    crawler.is_default = True
    db.session.commit()
    
    return jsonify({
        'code': 0,
        'msg': f'已将 {crawler.name} 设为默认爬虫'
    })


@admin_bp.route('/api/crawlers/<int:crawler_id>/test', methods=['POST'])
@login_required
def test_crawler(crawler_id):
    """测试爬虫配置"""
    import requests
    from datetime import datetime
    
    crawler = CrawlerConfig.query.get_or_404(crawler_id)
    
    try:
        # 构建请求头
        headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
            'Accept-Language': 'zh-CN,zh;q=0.9'
        }
        headers.update(crawler.get_headers())
        
        # 发送测试请求
        test_url = crawler.base_url
        response = requests.get(test_url, headers=headers, timeout=crawler.request_timeout)
        response.encoding = crawler.encoding or response.apparent_encoding
        
        # 更新统计
        crawler.crawl_count = (crawler.crawl_count or 0) + 1
        crawler.last_crawl_at = datetime.utcnow()
        
        if response.status_code == 200:
            crawler.success_count = (crawler.success_count or 0) + 1
            crawler.last_error = None
            db.session.commit()
            
            return jsonify({
                'code': 0,
                'msg': '连接测试成功',
                'data': {
                    'status_code': response.status_code,
                    'content_length': len(response.text),
                    'encoding': response.encoding
                }
            })
        else:
            crawler.fail_count = (crawler.fail_count or 0) + 1
            crawler.last_error = f'HTTP {response.status_code}'
            db.session.commit()
            
            return jsonify({
                'code': 1,
                'msg': f'请求返回错误状态码: {response.status_code}'
            })
            
    except requests.Timeout:
        crawler.fail_count = (crawler.fail_count or 0) + 1
        crawler.last_error = '请求超时'
        db.session.commit()
        return jsonify({'code': 1, 'msg': '请求超时，请检查URL或增加超时时间'})
    except requests.RequestException as e:
        crawler.fail_count = (crawler.fail_count or 0) + 1
        crawler.last_error = str(e)
        db.session.commit()
        return jsonify({'code': 1, 'msg': f'请求失败: {str(e)}'})
    except Exception as e:
        return jsonify({'code': 1, 'msg': f'测试失败: {str(e)}'})


@admin_bp.route('/api/crawlers/<int:crawler_id>/crawl', methods=['POST'])
@login_required
def crawl_with_crawler(crawler_id):
    """使用指定爬虫进行数据采集"""
    from datetime import datetime
    
    crawler = CrawlerConfig.query.get_or_404(crawler_id)
    
    if not crawler.is_enabled:
        return jsonify({'code': 1, 'msg': '该爬虫已禁用'})
    
    data = request.get_json()
    keyword = data.get('keyword', '').strip()
    pages = data.get('pages', 1)
    
    try:
        results = []
        
        # 根据爬虫类型调用对应的采集方法
        if crawler.crawler_type == 'baidu':
            results = fetch_news(keyword, pages=pages)
        elif crawler.crawler_type == 'xinhua':
            results = fetch_xinhua_news(keyword if keyword else None)
        else:
            # 自定义爬虫，使用配置的选择器进行采集
            results = crawl_with_custom_config(crawler, keyword, pages)
        
        # 更新统计
        crawler.crawl_count = (crawler.crawl_count or 0) + 1
        crawler.success_count = (crawler.success_count or 0) + 1
        crawler.last_crawl_at = datetime.utcnow()
        crawler.last_error = None
        db.session.commit()
        
        return jsonify({
            'code': 0,
            'msg': 'success',
            'count': len(results),
            'crawler_id': crawler_id,
            'crawler_name': crawler.name,
            'keyword': keyword,
            'data': results
        })
        
    except Exception as e:
        crawler.fail_count = (crawler.fail_count or 0) + 1
        crawler.last_error = str(e)
        db.session.commit()
        return jsonify({'code': 1, 'msg': f'采集失败: {str(e)}'})


def crawl_with_custom_config(crawler, keyword=None, pages=1):
    """使用自定义配置进行采集"""
    import requests
    from bs4 import BeautifulSoup
    import time
    import random
    
    results = []
    
    headers = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
        'Accept-Language': 'zh-CN,zh;q=0.9'
    }
    headers.update(crawler.get_headers())
    
    for page in range(pages):
        # 构建URL
        url = crawler.search_url or crawler.base_url
        if keyword and '{keyword}' in url:
            url = url.replace('{keyword}', keyword)
        if '{page}' in url:
            url = url.replace('{page}', str(page * 10))
        
        # 请求延迟
        if page > 0:
            time.sleep(crawler.request_delay or 1.0)
        
        try:
            response = requests.get(url, headers=headers, timeout=crawler.request_timeout or 15)
            response.encoding = crawler.encoding or response.apparent_encoding
            
            soup = BeautifulSoup(response.text, 'html.parser')
            
            # 使用配置的选择器提取数据
            items = []
            if crawler.list_selector:
                items = soup.select(crawler.list_selector)
            
            for item in items:
                news_data = {
                    'title': '',
                    'summary': '',
                    'cover': '',
                    'url': '',
                    'source': crawler.name
                }
                
                # 提取标题
                if crawler.title_selector:
                    title_elem = item.select_one(crawler.title_selector)
                    if title_elem:
                        news_data['title'] = title_elem.get_text(strip=True)
                
                # 提取链接
                if crawler.link_selector:
                    link_elem = item.select_one(crawler.link_selector)
                    if link_elem:
                        news_data['url'] = link_elem.get('href', '')
                
                # 提取摘要
                if crawler.summary_selector:
                    summary_elem = item.select_one(crawler.summary_selector)
                    if summary_elem:
                        news_data['summary'] = summary_elem.get_text(strip=True)[:200]
                
                # 提取封面
                if crawler.cover_selector:
                    cover_elem = item.select_one(crawler.cover_selector)
                    if cover_elem:
                        news_data['cover'] = cover_elem.get('src', '') or cover_elem.get('data-src', '')
                
                # 提取来源
                if crawler.source_selector:
                    source_elem = item.select_one(crawler.source_selector)
                    if source_elem:
                        news_data['source'] = source_elem.get_text(strip=True)
                
                if news_data['title']:
                    results.append(news_data)
                    
        except Exception as e:
            print(f"采集页面 {page + 1} 失败: {e}")
            continue
    
    return results
