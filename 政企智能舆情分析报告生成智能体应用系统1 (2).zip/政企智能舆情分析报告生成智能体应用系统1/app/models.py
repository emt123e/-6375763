"""
数据库模型定义
"""
from datetime import datetime
from werkzeug.security import generate_password_hash, check_password_hash
from flask_login import UserMixin
from app import db


class Role(db.Model):
    """角色模型"""
    __tablename__ = 'roles'
    
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(64), unique=True, nullable=False)
    description = db.Column(db.String(200))
    permissions = db.Column(db.String(500))  # 权限列表，JSON格式
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    # 关联用户
    users = db.relationship('User', backref='role', lazy='dynamic')
    
    def __repr__(self):
        return f'<Role {self.name}>'
    
    def to_dict(self):
        return {
            'id': self.id,
            'name': self.name,
            'description': self.description,
            'permissions': self.permissions,
            'created_at': self.created_at.strftime('%Y-%m-%d %H:%M:%S') if self.created_at else None
        }
    
    @staticmethod
    def init_roles():
        """初始化默认角色"""
        roles = [
            {'name': 'admin', 'description': '管理员', 'permissions': 'all'},
            {'name': 'user', 'description': '普通用户', 'permissions': 'view_dashboard,view_reports'}
        ]
        for r in roles:
            role = Role.query.filter_by(name=r['name']).first()
            if role is None:
                role = Role(name=r['name'], description=r['description'], permissions=r['permissions'])
                db.session.add(role)
        db.session.commit()


class User(UserMixin, db.Model):
    """用户模型"""
    __tablename__ = 'users'
    
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(64), unique=True, nullable=False, index=True)
    password_hash = db.Column(db.String(256))
    email = db.Column(db.String(120), unique=True, index=True)
    realname = db.Column(db.String(64))  # 真实姓名
    phone = db.Column(db.String(20))  # 手机号
    avatar = db.Column(db.String(200))  # 头像
    is_active = db.Column(db.Boolean, default=True)  # 是否启用
    role_id = db.Column(db.Integer, db.ForeignKey('roles.id'))  # 角色ID
    last_login = db.Column(db.DateTime)  # 最后登录时间
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    def __repr__(self):
        return f'<User {self.username}>'
    
    def set_password(self, password):
        """设置密码（加密存储）"""
        self.password_hash = generate_password_hash(password)
    
    def check_password(self, password):
        """验证密码"""
        return check_password_hash(self.password_hash, password)
    
    def is_admin(self):
        """判断是否为管理员"""
        return self.role and self.role.name == 'admin'
    
    def has_permission(self, permission):
        """检查是否有某个权限"""
        if not self.role:
            return False
        if self.role.permissions == 'all':
            return True
        return permission in self.role.permissions.split(',')
    
    def to_dict(self):
        return {
            'id': self.id,
            'username': self.username,
            'email': self.email,
            'realname': self.realname,
            'phone': self.phone,
            'avatar': self.avatar,
            'is_active': self.is_active,
            'role_id': self.role_id,
            'role_name': self.role.description if self.role else None,
            'last_login': self.last_login.strftime('%Y-%m-%d %H:%M:%S') if self.last_login else None,
            'created_at': self.created_at.strftime('%Y-%m-%d %H:%M:%S') if self.created_at else None
        }
    
    @staticmethod
    def init_admin():
        """初始化管理员账户"""
        admin_role = Role.query.filter_by(name='admin').first()
        if admin_role:
            admin = User.query.filter_by(username='admin').first()
            if admin is None:
                admin = User(
                    username='admin',
                    email='admin@example.com',
                    realname='系统管理员',
                    role_id=admin_role.id,
                    is_active=True
                )
                admin.set_password('admin123')
                db.session.add(admin)
                db.session.commit()


class SystemSetting(db.Model):
    """系统设置模型"""
    __tablename__ = 'system_settings'
    
    id = db.Column(db.Integer, primary_key=True)
    key = db.Column(db.String(64), unique=True, nullable=False, index=True)
    value = db.Column(db.Text)
    description = db.Column(db.String(200))
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    def __repr__(self):
        return f'<SystemSetting {self.key}>'
    
    def to_dict(self):
        return {
            'id': self.id,
            'key': self.key,
            'value': self.value,
            'description': self.description,
            'updated_at': self.updated_at.strftime('%Y-%m-%d %H:%M:%S') if self.updated_at else None
        }
    
    @staticmethod
    def get_setting(key, default=None):
        """获取系统设置值"""
        setting = SystemSetting.query.filter_by(key=key).first()
        return setting.value if setting else default
    
    @staticmethod
    def set_setting(key, value, description=None):
        """设置系统设置值"""
        setting = SystemSetting.query.filter_by(key=key).first()
        if setting:
            setting.value = value
            if description:
                setting.description = description
        else:
            setting = SystemSetting(key=key, value=value, description=description)
            db.session.add(setting)
        db.session.commit()
        return setting
    
    @staticmethod
    def init_settings():
        """初始化默认系统设置"""
        default_settings = [
            {'key': 'app_name', 'value': '政企智能舆情分析系统', 'description': '应用名称'},
            {'key': 'app_logo', 'value': '', 'description': '应用LOGO路径'},
            {'key': 'app_copyright', 'value': 'Copyright © 2024 政企智能舆情分析系统 All Rights Reserved', 'description': '版权信息'}
        ]
        for s in default_settings:
            existing = SystemSetting.query.filter_by(key=s['key']).first()
            if not existing:
                setting = SystemSetting(**s)
                db.session.add(setting)
        db.session.commit()


class CollectedData(db.Model):
    """采集数据模型"""
    __tablename__ = 'collected_data'
    
    id = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String(500), nullable=False)  # 标题
    summary = db.Column(db.Text)  # 摘要
    content = db.Column(db.Text)  # 深度采集的正文内容
    cover = db.Column(db.String(500))  # 封面图片
    url = db.Column(db.String(1000))  # 原始链接
    source = db.Column(db.String(200))  # 来源
    keyword = db.Column(db.String(200))  # 采集关键词
    is_deep_collected = db.Column(db.Boolean, default=False)  # 是否已深度采集
    deep_collected_at = db.Column(db.DateTime)  # 深度采集时间
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    # 绑定的采集规则ID列表（JSON格式存储，支持多个规则）
    bound_rule_ids = db.Column(db.Text)  # 格式: "[1,2,3]"
    
    # 外键关联
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'))
    user = db.relationship('User', backref=db.backref('collected_data', lazy='dynamic'))
    
    def __repr__(self):
        return f'<CollectedData {self.title[:30]}>'
    
    def get_bound_rules(self):
        """获取绑定的规则ID列表"""
        import json
        if self.bound_rule_ids:
            try:
                return json.loads(self.bound_rule_ids)
            except:
                return []
        return []
    
    def set_bound_rules(self, rule_ids):
        """设置绑定的规则ID列表"""
        import json
        self.bound_rule_ids = json.dumps(rule_ids) if rule_ids else None
    
    def to_dict(self):
        return {
            'id': self.id,
            'title': self.title,
            'summary': self.summary,
            'content': self.content,
            'cover': self.cover,
            'url': self.url,
            'source': self.source,
            'keyword': self.keyword,
            'is_deep_collected': self.is_deep_collected,
            'deep_collected_at': self.deep_collected_at.strftime('%Y-%m-%d %H:%M:%S') if self.deep_collected_at else None,
            'created_at': self.created_at.strftime('%Y-%m-%d %H:%M:%S') if self.created_at else None,
            'bound_rule_ids': self.get_bound_rules()
        }


class CollectedContent(db.Model):
    """采集详细内容模型 - 专门保存深度采集的标题和内容"""
    __tablename__ = 'collected_contents'
    
    id = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String(500), nullable=False)  # 采集的标题
    content = db.Column(db.Text)  # 采集的详细内容
    original_url = db.Column(db.String(1000))  # 原始链接
    source = db.Column(db.String(200))  # 来源站点
    rule_name = db.Column(db.String(200))  # 使用的采集规则名称
    content_length = db.Column(db.Integer, default=0)  # 内容字数
    collected_at = db.Column(db.DateTime, default=datetime.utcnow)  # 采集时间
    
    # 关联到原始采集数据
    collected_data_id = db.Column(db.Integer, db.ForeignKey('collected_data.id'))
    collected_data = db.relationship('CollectedData', backref=db.backref('detail_content', uselist=False))
    
    # 采集用户
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'))
    user = db.relationship('User', backref=db.backref('collected_contents', lazy='dynamic'))
    
    def __repr__(self):
        return f'<CollectedContent {self.title[:30]}>'
    
    def to_dict(self):
        return {
            'id': self.id,
            'title': self.title,
            'content': self.content,
            'original_url': self.original_url,
            'source': self.source,
            'rule_name': self.rule_name,
            'content_length': self.content_length,
            'collected_at': self.collected_at.strftime('%Y-%m-%d %H:%M:%S') if self.collected_at else None,
            'collected_data_id': self.collected_data_id
        }


class SentimentReport(db.Model):
    """舆情报告模型"""
    __tablename__ = 'sentiment_reports'
    
    id = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String(200), nullable=False)
    content = db.Column(db.Text)
    source = db.Column(db.String(100))  # 来源
    url = db.Column(db.String(500))  # 原始链接
    cover = db.Column(db.String(500))  # 封面图片
    sentiment = db.Column(db.String(20))  # 情感倾向: positive/negative/neutral
    keywords = db.Column(db.String(500))  # 关键词
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # 外键关联
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'))
    user = db.relationship('User', backref=db.backref('reports', lazy='dynamic'))
    
    def __repr__(self):
        return f'<SentimentReport {self.title}>'
    
    def to_dict(self):
        """转换为字典"""
        return {
            'id': self.id,
            'title': self.title,
            'content': self.content,
            'source': self.source,
            'url': self.url,
            'cover': self.cover,
            'sentiment': self.sentiment,
            'keywords': self.keywords,
            'created_at': self.created_at.strftime('%Y-%m-%d %H:%M:%S') if self.created_at else None,
            'updated_at': self.updated_at.strftime('%Y-%m-%d %H:%M:%S') if self.updated_at else None
        }


class CrawlRule(db.Model):
    """采集规则模型"""
    __tablename__ = 'crawl_rules'
    
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)  # 规则名称
    site_name = db.Column(db.String(100), nullable=False)  # 站点名称
    site_url = db.Column(db.String(500), nullable=False)  # 站点URL
    
    # XPath配置
    title_xpath = db.Column(db.String(500))  # 标题XPath
    content_xpath = db.Column(db.String(500))  # 详细内容XPath
    list_xpath = db.Column(db.String(500))  # 列表项XPath
    link_xpath = db.Column(db.String(500))  # 链接XPath
    summary_xpath = db.Column(db.String(500))  # 摘要XPath
    cover_xpath = db.Column(db.String(500))  # 封面图XPath
    date_xpath = db.Column(db.String(500))  # 日期XPath
    
    # Request Headers配置（JSON格式存储）
    request_headers = db.Column(db.Text)  # 请求头配置
    
    # 其他配置
    encoding = db.Column(db.String(20), default='utf-8')  # 页面编码
    is_enabled = db.Column(db.Boolean, default=True)  # 是否启用
    description = db.Column(db.Text)  # 规则描述
    
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # 外键关联
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'))
    user = db.relationship('User', backref=db.backref('crawl_rules', lazy='dynamic'))
    
    def __repr__(self):
        return f'<CrawlRule {self.name}>'
    
    def to_dict(self):
        """转换为字典"""
        import json
        headers = {}
        if self.request_headers:
            try:
                headers = json.loads(self.request_headers)
            except:
                pass
        
        return {
            'id': self.id,
            'name': self.name,
            'site_name': self.site_name,
            'site_url': self.site_url,
            'title_xpath': self.title_xpath,
            'content_xpath': self.content_xpath,
            'list_xpath': self.list_xpath,
            'link_xpath': self.link_xpath,
            'summary_xpath': self.summary_xpath,
            'cover_xpath': self.cover_xpath,
            'date_xpath': self.date_xpath,
            'request_headers': headers,
            'encoding': self.encoding,
            'is_enabled': self.is_enabled,
            'description': self.description,
            'created_at': self.created_at.strftime('%Y-%m-%d %H:%M:%S') if self.created_at else None,
            'updated_at': self.updated_at.strftime('%Y-%m-%d %H:%M:%S') if self.updated_at else None
        }
    
    @staticmethod
    def init_default_rules():
        """初始化默认采集规则"""
        import json
        default_rules = [
            {
                'name': '百度新闻采集规则',
                'site_name': '百度新闻',
                'site_url': 'https://news.baidu.com',
                'description': '百度新闻搜索结果页面的采集规则',
                'list_xpath': '//div[contains(@class,"result")]',
                'title_xpath': './/h3/a/text()',
                'link_xpath': './/h3/a/@href',
                'summary_xpath': './/span[contains(@class,"c-font-normal")]//text()',
                'encoding': 'utf-8',
                'is_enabled': True
            },
            {
                'name': '新华网四川采集规则',
                'site_name': '新华网四川',
                'site_url': 'http://sc.news.cn',
                'description': '新华网四川频道要闻页面的采集规则',
                'list_xpath': '//div[@class="domPC"]//li',
                'title_xpath': './/a/text()',
                'link_xpath': './/a/@href',
                'encoding': 'utf-8',
                'is_enabled': True
            },
            {
                'name': '人民网采集规则',
                'site_name': '人民网',
                'site_url': 'http://www.people.com.cn',
                'description': '人民网新闻页面的采集规则',
                'list_xpath': '//ul[@class="list_14"]/li',
                'title_xpath': './/a/text()',
                'link_xpath': './/a/@href',
                'encoding': 'gb2312',
                'is_enabled': True
            },
            {
                'name': '新浪新闻采集规则',
                'site_name': '新浪新闻',
                'site_url': 'https://news.sina.com.cn',
                'description': '新浪新闻页面的采集规则',
                'list_xpath': '//div[@class="news-item"]',
                'title_xpath': './/h2/a/text()',
                'link_xpath': './/h2/a/@href',
                'summary_xpath': './/p/text()',
                'encoding': 'utf-8',
                'is_enabled': True
            }
        ]
        
        added_count = 0
        for rule_data in default_rules:
            # 检查是否已存在同名规则
            existing = CrawlRule.query.filter_by(name=rule_data['name']).first()
            if not existing:
                rule = CrawlRule(**rule_data)
                db.session.add(rule)
                added_count += 1
        
        if added_count > 0:
            db.session.commit()
        
        return added_count


class CrawlerConfig(db.Model):
    """爬虫配置模型 - 管理多爬虫数据源及配置"""
    __tablename__ = 'crawler_configs'
    
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)  # 爬虫名称
    crawler_type = db.Column(db.String(50), nullable=False)  # 爬虫类型: baidu/xinhua/custom
    description = db.Column(db.Text)  # 描述
    
    # 基础配置
    base_url = db.Column(db.String(500))  # 基础URL
    search_url = db.Column(db.String(500))  # 搜索URL模板
    encoding = db.Column(db.String(20), default='utf-8')  # 页面编码
    
    # 请求配置
    request_headers = db.Column(db.Text)  # 请求头配置（JSON格式）
    request_timeout = db.Column(db.Integer, default=15)  # 请求超时时间
    request_delay = db.Column(db.Float, default=1.0)  # 请求间隔（秒）
    max_retries = db.Column(db.Integer, default=3)  # 最大重试次数
    
    # 解析配置（支持XPath和CSS选择器）
    list_selector = db.Column(db.String(500))  # 列表项选择器
    title_selector = db.Column(db.String(500))  # 标题选择器
    link_selector = db.Column(db.String(500))  # 链接选择器
    summary_selector = db.Column(db.String(500))  # 摘要选择器
    cover_selector = db.Column(db.String(500))  # 封面图选择器
    source_selector = db.Column(db.String(500))  # 来源选择器
    date_selector = db.Column(db.String(500))  # 日期选择器
    content_selector = db.Column(db.String(500))  # 详情页内容选择器
    
    # 状态
    is_enabled = db.Column(db.Boolean, default=True)  # 是否启用
    is_default = db.Column(db.Boolean, default=False)  # 是否默认爬虫
    priority = db.Column(db.Integer, default=0)  # 优先级（越大越优先）
    
    # 图标和样式
    icon = db.Column(db.String(50), default='layui-icon-website')  # 图标
    color = db.Column(db.String(20), default='#1E9FFF')  # 主题色
    
    # 统计
    crawl_count = db.Column(db.Integer, default=0)  # 采集次数
    success_count = db.Column(db.Integer, default=0)  # 成功次数
    fail_count = db.Column(db.Integer, default=0)  # 失败次数
    last_crawl_at = db.Column(db.DateTime)  # 最后采集时间
    last_error = db.Column(db.Text)  # 最后错误信息
    
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # 外键关联
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'))
    user = db.relationship('User', backref=db.backref('crawler_configs', lazy='dynamic'))
    
    def __repr__(self):
        return f'<CrawlerConfig {self.name}>'
    
    def get_headers(self):
        """获取请求头字典"""
        import json
        if self.request_headers:
            try:
                return json.loads(self.request_headers)
            except:
                return {}
        return {}
    
    def set_headers(self, headers_dict):
        """设置请求头"""
        import json
        self.request_headers = json.dumps(headers_dict, ensure_ascii=False) if headers_dict else None
    
    def to_dict(self):
        """转换为字典"""
        return {
            'id': self.id,
            'name': self.name,
            'crawler_type': self.crawler_type,
            'description': self.description,
            'base_url': self.base_url,
            'search_url': self.search_url,
            'encoding': self.encoding,
            'request_headers': self.get_headers(),
            'request_timeout': self.request_timeout,
            'request_delay': self.request_delay,
            'max_retries': self.max_retries,
            'list_selector': self.list_selector,
            'title_selector': self.title_selector,
            'link_selector': self.link_selector,
            'summary_selector': self.summary_selector,
            'cover_selector': self.cover_selector,
            'source_selector': self.source_selector,
            'date_selector': self.date_selector,
            'content_selector': self.content_selector,
            'is_enabled': self.is_enabled,
            'is_default': self.is_default,
            'priority': self.priority,
            'icon': self.icon,
            'color': self.color,
            'crawl_count': self.crawl_count,
            'success_count': self.success_count,
            'fail_count': self.fail_count,
            'last_crawl_at': self.last_crawl_at.strftime('%Y-%m-%d %H:%M:%S') if self.last_crawl_at else None,
            'last_error': self.last_error,
            'created_at': self.created_at.strftime('%Y-%m-%d %H:%M:%S') if self.created_at else None,
            'updated_at': self.updated_at.strftime('%Y-%m-%d %H:%M:%S') if self.updated_at else None
        }
    
    @staticmethod
    def init_default_crawlers():
        """初始化默认爬虫配置"""
        default_crawlers = [
            {
                'name': '百度新闻',
                'crawler_type': 'baidu',
                'description': '百度新闻搜索，支持关键词搜索采集',
                'base_url': 'https://www.baidu.com/s',
                'search_url': 'https://www.baidu.com/s?rtt=1&bsst=1&cl=2&tn=news&word={keyword}&pn={page}',
                'is_enabled': True,
                'is_default': True,
                'priority': 100,
                'icon': 'layui-icon-search',
                'color': '#3385FF'
            },
            {
                'name': '新华网四川',
                'crawler_type': 'xinhua',
                'description': '新华网四川频道要闻采集',
                'base_url': 'http://sc.news.cn/scyw.htm',
                'is_enabled': True,
                'is_default': False,
                'priority': 90,
                'icon': 'layui-icon-read',
                'color': '#D81E06'
            }
        ]
        
        for crawler_data in default_crawlers:
            existing = CrawlerConfig.query.filter_by(name=crawler_data['name']).first()
            if not existing:
                crawler = CrawlerConfig(**crawler_data)
                db.session.add(crawler)
        
        db.session.commit()


class AIEngine(db.Model):
    """AI引擎模型 - 管理第三方大模型服务接入"""
    __tablename__ = 'ai_engines'
    
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)  # 引擎名称
    provider = db.Column(db.String(100), nullable=False)  # 服务商名称
    api_url = db.Column(db.String(500), nullable=False)  # API地址
    api_key = db.Column(db.String(500), nullable=False)  # API密钥
    model_name = db.Column(db.String(100), nullable=False)  # 模型名称
    
    # 可选配置
    max_tokens = db.Column(db.Integer, default=2000)  # 最大token数
    temperature = db.Column(db.Float, default=0.7)  # 温度参数
    timeout = db.Column(db.Integer, default=60)  # 超时时间(秒)
    
    # 状态
    is_enabled = db.Column(db.Boolean, default=True)  # 是否启用
    is_default = db.Column(db.Boolean, default=False)  # 是否默认引擎
    description = db.Column(db.Text)  # 描述
    icon = db.Column(db.String(50), default='layui-icon-fire')  # 图标
    color = db.Column(db.String(20), default='#667eea')  # 主题色
    
    # 统计
    call_count = db.Column(db.Integer, default=0)  # 调用次数
    last_used_at = db.Column(db.DateTime)  # 最后使用时间
    
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # 外键关联
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'))
    user = db.relationship('User', backref=db.backref('ai_engines', lazy='dynamic'))
    
    def __repr__(self):
        return f'<AIEngine {self.name}>'
    
    def to_dict(self):
        """转换为字典"""
        return {
            'id': self.id,
            'name': self.name,
            'provider': self.provider,
            'api_url': self.api_url,
            'api_key': self.api_key[:8] + '****' if self.api_key and len(self.api_key) > 8 else '****',
            'api_key_full': self.api_key,
            'model_name': self.model_name,
            'max_tokens': self.max_tokens,
            'temperature': self.temperature,
            'timeout': self.timeout,
            'is_enabled': self.is_enabled,
            'is_default': self.is_default,
            'description': self.description,
            'icon': self.icon,
            'color': self.color,
            'call_count': self.call_count,
            'last_used_at': self.last_used_at.strftime('%Y-%m-%d %H:%M:%S') if self.last_used_at else None,
            'created_at': self.created_at.strftime('%Y-%m-%d %H:%M:%S') if self.created_at else None,
            'updated_at': self.updated_at.strftime('%Y-%m-%d %H:%M:%S') if self.updated_at else None
        }
    
    def to_safe_dict(self):
        """转换为安全字典（不包含完整密钥）"""
        data = self.to_dict()
        del data['api_key_full']
        return data
