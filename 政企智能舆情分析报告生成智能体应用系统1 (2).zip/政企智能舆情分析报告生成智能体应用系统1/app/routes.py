"""
路由定义
"""
from flask import Blueprint, render_template, jsonify, request
from flask_login import login_required, current_user
from app import db
from app.models import SentimentReport, CollectedData, CrawlRule, CollectedContent
from app.crawler import fetch_news
from datetime import datetime
import requests
from lxml import etree
import json
import re

# 创建蓝图
main_bp = Blueprint('main', __name__)


@main_bp.route('/')
@login_required
def index():
    """首页"""
    return render_template('index.html')


@main_bp.route('/api/health')
def health_check():
    """健康检查接口"""
    return jsonify({
        'status': 'ok',
        'message': '系统运行正常'
    })


@main_bp.route('/api/search', methods=['GET', 'POST'])
@login_required
def search_news():
    """搜索舆情数据"""
    if request.method == 'POST':
        data = request.get_json()
        keyword = data.get('keyword', '').strip()
        pages = data.get('pages', 1)
    else:
        keyword = request.args.get('keyword', '').strip()
        pages = request.args.get('pages', 1, type=int)
    
    if not keyword:
        return jsonify({
            'code': 1,
            'msg': '请输入搜索关键字'
        })
    
    try:
        # 调用爬虫获取数据
        results = fetch_news(keyword, pages=pages)
        
        return jsonify({
            'code': 0,
            'msg': 'success',
            'count': len(results),
            'keyword': keyword,
            'data': results
        })
    except Exception as e:
        return jsonify({
            'code': 1,
            'msg': f'搜索失败: {str(e)}'
        })


@main_bp.route('/api/search/save', methods=['POST'])
@login_required
def save_search_result():
    """保存搜索结果到舆情报告"""
    data = request.get_json()
    
    if not data or not data.get('title'):
        return jsonify({
            'code': 1,
            'msg': '标题不能为空'
        })
    
    report = SentimentReport(
        title=data.get('title'),
        content=data.get('summary', ''),
        source=data.get('source', ''),
        url=data.get('url', ''),
        cover=data.get('cover', ''),
        keywords=data.get('keyword', ''),
        sentiment='neutral'  # 默认中性，后续可通过AI分析
    )
    
    db.session.add(report)
    db.session.commit()
    
    return jsonify({
        'code': 0,
        'msg': '保存成功',
        'data': report.to_dict()
    })


@main_bp.route('/api/reports', methods=['GET'])
def get_reports():
    """获取舆情报告列表"""
    page = request.args.get('page', 1, type=int)
    per_page = request.args.get('limit', 10, type=int)
    
    pagination = SentimentReport.query.order_by(
        SentimentReport.created_at.desc()
    ).paginate(page=page, per_page=per_page, error_out=False)
    
    reports = [report.to_dict() for report in pagination.items]
    
    return jsonify({
        'code': 0,
        'msg': 'success',
        'count': pagination.total,
        'data': reports
    })


@main_bp.route('/api/reports', methods=['POST'])
def create_report():
    """创建舆情报告"""
    data = request.get_json()
    
    if not data or not data.get('title'):
        return jsonify({
            'code': 1,
            'msg': '标题不能为空'
        }), 400
    
    report = SentimentReport(
        title=data.get('title'),
        content=data.get('content'),
        source=data.get('source'),
        sentiment=data.get('sentiment'),
        keywords=data.get('keywords')
    )
    
    db.session.add(report)
    db.session.commit()
    
    return jsonify({
        'code': 0,
        'msg': '创建成功',
        'data': report.to_dict()
    })


@main_bp.route('/api/reports/<int:report_id>', methods=['GET'])
def get_report(report_id):
    """获取单个舆情报告"""
    report = SentimentReport.query.get_or_404(report_id)
    return jsonify({
        'code': 0,
        'msg': 'success',
        'data': report.to_dict()
    })


@main_bp.route('/api/reports/<int:report_id>', methods=['PUT'])
def update_report(report_id):
    """更新舆情报告"""
    report = SentimentReport.query.get_or_404(report_id)
    data = request.get_json()
    
    if data.get('title'):
        report.title = data['title']
    if data.get('content'):
        report.content = data['content']
    if data.get('source'):
        report.source = data['source']
    if data.get('sentiment'):
        report.sentiment = data['sentiment']
    if data.get('keywords'):
        report.keywords = data['keywords']
    
    db.session.commit()
    
    return jsonify({
        'code': 0,
        'msg': '更新成功',
        'data': report.to_dict()
    })


@main_bp.route('/api/reports/<int:report_id>', methods=['DELETE'])
def delete_report(report_id):
    """删除舆情报告"""
    report = SentimentReport.query.get_or_404(report_id)
    db.session.delete(report)
    db.session.commit()
    
    return jsonify({
        'code': 0,
        'msg': '删除成功'
    })


# ==================== 仓库功能 ====================

@main_bp.route('/warehouse')
@login_required
def warehouse():
    """仓库页面"""
    return render_template('warehouse.html')


@main_bp.route('/api/warehouse/save', methods=['POST'])
@login_required
def warehouse_save():
    """保存数据到仓库"""
    data = request.get_json()
    items = data.get('items', [])
    keyword = data.get('keyword', '')
    
    # 如果是单条数据
    if not items and data.get('title'):
        items = [data]
    
    if not items:
        return jsonify({'code': 1, 'msg': '没有要保存的数据'})
    
    saved_count = 0
    skipped_count = 0
    
    for item in items:
        # 检查是否已存在（根据URL去重）
        url = item.get('url', '')
        if url:
            existing = CollectedData.query.filter_by(url=url).first()
            if existing:
                skipped_count += 1
                continue
        
        collected = CollectedData(
            title=item.get('title', ''),
            summary=item.get('summary', ''),
            content=item.get('content', ''),
            cover=item.get('cover', ''),
            url=item.get('url', ''),
            source=item.get('source', ''),
            keyword=keyword,
            is_deep_collected=False,
            user_id=current_user.id
        )
        
        db.session.add(collected)
        saved_count += 1
    
    db.session.commit()
    
    if skipped_count > 0:
        return jsonify({
            'code': 0,
            'msg': f'保存成功！新增 {saved_count} 条，跳过 {skipped_count} 条重复数据'
        })
    
    return jsonify({
        'code': 0,
        'msg': f'成功保存 {saved_count} 条数据到仓库'
    })


@main_bp.route('/api/warehouse/list', methods=['GET'])
@login_required
def warehouse_list():
    """获取仓库数据列表"""
    page = request.args.get('page', 1, type=int)
    limit = request.args.get('limit', 10, type=int)
    keyword = request.args.get('keyword', '')
    
    query = CollectedData.query
    if keyword:
        query = query.filter(
            db.or_(
                CollectedData.title.like(f'%{keyword}%'),
                CollectedData.keyword.like(f'%{keyword}%'),
                CollectedData.source.like(f'%{keyword}%')
            )
        )
    
    pagination = query.order_by(CollectedData.created_at.desc()).paginate(
        page=page, per_page=limit, error_out=False
    )
    
    return jsonify({
        'code': 0,
        'msg': 'success',
        'count': pagination.total,
        'data': [item.to_dict() for item in pagination.items]
    })


@main_bp.route('/api/warehouse/<int:item_id>', methods=['GET'])
@login_required
def warehouse_get(item_id):
    """获取仓库单条数据（预览功能）"""
    item = CollectedData.query.get_or_404(item_id)
    data = item.to_dict()
    
    # 从采集内容表读取详细内容
    content_record = CollectedContent.query.filter_by(collected_data_id=item.id).first()
    if content_record:
        # 有采集记录，从新表读取
        data['content'] = content_record.content
        data['collected_title'] = content_record.title
        data['content_length'] = content_record.content_length
        data['rule_name'] = content_record.rule_name
        data['content_collected_at'] = content_record.collected_at.strftime('%Y-%m-%d %H:%M:%S') if content_record.collected_at else None
        data['is_deep_collected'] = True  # 有记录则为已采集
    else:
        # 无采集记录，深度采集状态为未采集
        data['is_deep_collected'] = False
        data['content_length'] = 0
    
    return jsonify({
        'code': 0,
        'data': data
    })


@main_bp.route('/api/warehouse/<int:item_id>', methods=['DELETE'])
@login_required
def warehouse_delete(item_id):
    """删除仓库数据"""
    item = CollectedData.query.get_or_404(item_id)
    db.session.delete(item)
    db.session.commit()
    return jsonify({'code': 0, 'msg': '删除成功'})


@main_bp.route('/api/warehouse/batch_delete', methods=['POST'])
@login_required
def warehouse_batch_delete():
    """批量删除仓库数据"""
    data = request.get_json()
    ids = data.get('ids', [])
    
    if not ids:
        return jsonify({'code': 1, 'msg': '请选择要删除的数据'})
    
    CollectedData.query.filter(CollectedData.id.in_(ids)).delete(synchronize_session=False)
    db.session.commit()
    
    return jsonify({'code': 0, 'msg': f'成功删除 {len(ids)} 条数据'})


@main_bp.route('/api/warehouse/stats', methods=['GET'])
@login_required
def warehouse_stats():
    """获取仓库统计数据"""
    total = CollectedData.query.count()
    deep_collected = CollectedData.query.filter_by(is_deep_collected=True).count()
    
    return jsonify({
        'code': 0,
        'data': {
            'total': total,
            'deep_collected': deep_collected,
            'pending': total - deep_collected
        }
    })


@main_bp.route('/api/warehouse/<int:item_id>/bind_rules', methods=['POST'])
@login_required
def warehouse_bind_rules(item_id):
    """绑定采集规则到数据"""
    item = CollectedData.query.get_or_404(item_id)
    data = request.get_json()
    rule_ids = data.get('rule_ids', [])
    
    # 验证规则是否存在
    valid_rules = CrawlRule.query.filter(CrawlRule.id.in_(rule_ids)).all()
    valid_ids = [r.id for r in valid_rules]
    
    item.set_bound_rules(valid_ids)
    db.session.commit()
    
    return jsonify({
        'code': 0,
        'msg': f'成功绑定 {len(valid_ids)} 个规则',
        'data': {
            'bound_rule_ids': valid_ids,
            'rules': [{'id': r.id, 'name': r.name, 'site_name': r.site_name} for r in valid_rules]
        }
    })


@main_bp.route('/api/warehouse/<int:item_id>/bound_rules', methods=['GET'])
@login_required
def warehouse_get_bound_rules(item_id):
    """获取数据绑定的规则"""
    item = CollectedData.query.get_or_404(item_id)
    rule_ids = item.get_bound_rules()
    
    rules = []
    if rule_ids:
        rules = CrawlRule.query.filter(CrawlRule.id.in_(rule_ids)).all()
    
    return jsonify({
        'code': 0,
        'data': {
            'bound_rule_ids': rule_ids,
            'rules': [{'id': r.id, 'name': r.name, 'site_name': r.site_name} for r in rules]
        }
    })


@main_bp.route('/api/warehouse/batch_bind_rules', methods=['POST'])
@login_required
def warehouse_batch_bind_rules():
    """批量绑定规则到多条数据"""
    data = request.get_json()
    item_ids = data.get('item_ids', [])
    rule_ids = data.get('rule_ids', [])
    
    if not item_ids:
        return jsonify({'code': 1, 'msg': '请选择要绑定的数据'})
    if not rule_ids:
        return jsonify({'code': 1, 'msg': '请选择要绑定的规则'})
    
    # 验证规则
    valid_rules = CrawlRule.query.filter(CrawlRule.id.in_(rule_ids)).all()
    valid_ids = [r.id for r in valid_rules]
    
    # 批量更新
    items = CollectedData.query.filter(CollectedData.id.in_(item_ids)).all()
    for item in items:
        item.set_bound_rules(valid_ids)
    
    db.session.commit()
    
    return jsonify({
        'code': 0,
        'msg': f'成功为 {len(items)} 条数据绑定 {len(valid_ids)} 个规则'
    })


@main_bp.route('/api/warehouse/auto_bind_rules', methods=['POST'])
@login_required
def warehouse_auto_bind_rules():
    """根据来源自动匹配并绑定规则"""
    data = request.get_json()
    item_ids = data.get('item_ids', [])
    
    if not item_ids:
        # 如果没有指定，则处理所有未绑定规则的数据
        items = CollectedData.query.filter(
            (CollectedData.bound_rule_ids == None) | (CollectedData.bound_rule_ids == '[]')
        ).all()
    else:
        items = CollectedData.query.filter(CollectedData.id.in_(item_ids)).all()
    
    bound_count = 0
    for item in items:
        if item.source:
            # 查找匹配的规则
            matching_rules = CrawlRule.query.filter(
                CrawlRule.is_enabled == True,
                (CrawlRule.site_name.ilike(f'%{item.source}%')) | 
                (CrawlRule.site_url.ilike(f'%{item.source}%'))
            ).all()
            
            if matching_rules:
                rule_ids = [r.id for r in matching_rules]
                item.set_bound_rules(rule_ids)
                bound_count += 1
    
    db.session.commit()
    
    return jsonify({
        'code': 0,
        'msg': f'自动匹配完成，成功绑定 {bound_count} 条数据'
    })


@main_bp.route('/api/crawl_rules/all', methods=['GET'])
@login_required
def get_all_crawl_rules():
    """获取所有启用的采集规则（用于下拉选择）"""
    rules = CrawlRule.query.filter_by(is_enabled=True).order_by(CrawlRule.site_name).all()
    return jsonify({
        'code': 0,
        'data': [{'id': r.id, 'name': r.name, 'site_name': r.site_name, 'site_url': r.site_url} for r in rules]
    })


# ==================== 详细内容采集 ====================

def match_crawl_rule(source):
    """根据来源匹配采集规则"""
    if not source:
        return None
    
    # 精确匹配站点名称
    rule = CrawlRule.query.filter(
        CrawlRule.is_enabled == True,
        CrawlRule.site_name == source
    ).first()
    
    if rule:
        return rule
    
    # 模糊匹配
    rule = CrawlRule.query.filter(
        CrawlRule.is_enabled == True,
        CrawlRule.site_name.like(f'%{source}%')
    ).first()
    
    if rule:
        return rule
    
    # 反向模糊匹配
    rules = CrawlRule.query.filter(CrawlRule.is_enabled == True).all()
    for r in rules:
        if r.site_name in source or source in r.site_name:
            return r
    
    return None


def fetch_content_with_rule(url, rule):
    """使用规则采集详细内容"""
    try:
        # 构建请求头
        headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
            'Accept-Language': 'zh-CN,zh;q=0.9,en;q=0.8'
        }
        
        # 加载规则中的请求头
        if rule.request_headers:
            try:
                custom_headers = json.loads(rule.request_headers) if isinstance(rule.request_headers, str) else rule.request_headers
                headers.update(custom_headers)
            except:
                pass
        
        # 发送请求
        response = requests.get(url, headers=headers, timeout=15)
        response.encoding = rule.encoding or 'utf-8'
        
        # 解析HTML
        html = etree.HTML(response.text)
        
        result = {
            'title': '',
            'content': '',
            'rule_updated': False
        }
        
        # 提取标题
        if rule.title_xpath:
            titles = html.xpath(rule.title_xpath)
            if titles:
                if hasattr(titles[0], 'text'):
                    result['title'] = titles[0].text or ''
                else:
                    result['title'] = str(titles[0]).strip()
        
        # 如果没有通过xpath获取到标题，尝试通用方法
        if not result['title']:
            # 尝试常见的标题xpath
            common_title_xpaths = [
                '//h1//text()',
                '//title/text()',
                '//h1[@class="title"]//text()',
                '//div[@class="title"]//text()',
                '//article//h1//text()'
            ]
            for xpath in common_title_xpaths:
                try:
                    titles = html.xpath(xpath)
                    if titles:
                        result['title'] = ''.join([str(t).strip() for t in titles if str(t).strip()])
                        if result['title']:
                            # 自动更新规则
                            if not rule.title_xpath:
                                rule.title_xpath = xpath
                                result['rule_updated'] = True
                            break
                except:
                    continue
        
        # 提取内容
        if rule.content_xpath:
            contents = html.xpath(rule.content_xpath)
            if contents:
                content_texts = []
                for c in contents:
                    if hasattr(c, 'itertext'):
                        content_texts.append(''.join(c.itertext()))
                    elif hasattr(c, 'text') and c.text:
                        content_texts.append(c.text)
                    else:
                        content_texts.append(str(c).strip())
                result['content'] = '\n'.join([t.strip() for t in content_texts if t.strip()])
        
        # 如果没有通过xpath获取到内容，尝试通用方法
        if not result['content']:
            common_content_xpaths = [
                '//article//p//text()',
                '//div[@class="content"]//p//text()',
                '//div[@class="article-content"]//p//text()',
                '//div[@id="content"]//p//text()',
                '//div[contains(@class, "content")]//p//text()',
                '//div[contains(@class, "article")]//p//text()'
            ]
            for xpath in common_content_xpaths:
                try:
                    contents = html.xpath(xpath)
                    if contents and len(contents) > 2:
                        result['content'] = '\n'.join([str(t).strip() for t in contents if str(t).strip() and len(str(t).strip()) > 10])
                        if result['content'] and len(result['content']) > 100:
                            # 自动更新规则
                            if not rule.content_xpath:
                                rule.content_xpath = xpath
                                result['rule_updated'] = True
                            break
                except:
                    continue
        
        # 清理内容
        if result['content']:
            # 移除多余空白
            result['content'] = re.sub(r'\n\s*\n', '\n\n', result['content'])
            result['content'] = result['content'].strip()
        
        return result
        
    except Exception as e:
        return {'error': str(e)}


def fetch_content_generic(url):
    """通用内容采集（无规则时使用）"""
    try:
        headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36'
        }
        
        response = requests.get(url, headers=headers, timeout=15)
        response.encoding = response.apparent_encoding or 'utf-8'
        
        html = etree.HTML(response.text)
        
        result = {'title': '', 'content': ''}
        
        # 提取标题
        title_xpaths = ['//h1//text()', '//title/text()']
        for xpath in title_xpaths:
            titles = html.xpath(xpath)
            if titles:
                result['title'] = ''.join([str(t).strip() for t in titles if str(t).strip()])
                if result['title']:
                    break
        
        # 提取内容 - 尝试多种方式
        content_xpaths = [
            '//article//p//text()',
            '//div[contains(@class, "content")]//p//text()',
            '//div[contains(@class, "article")]//p//text()',
            '//div[@id="content"]//p//text()',
            '//main//p//text()'
        ]
        
        for xpath in content_xpaths:
            contents = html.xpath(xpath)
            if contents and len(contents) > 2:
                result['content'] = '\n'.join([str(t).strip() for t in contents if str(t).strip() and len(str(t).strip()) > 10])
                if result['content'] and len(result['content']) > 100:
                    break
        
        # 清理内容
        if result['content']:
            result['content'] = re.sub(r'\n\s*\n', '\n\n', result['content'])
            result['content'] = result['content'].strip()
        
        return result
        
    except Exception as e:
        return {'error': str(e)}


@main_bp.route('/api/warehouse/deep_collect/<int:item_id>', methods=['POST'])
@login_required
def warehouse_deep_collect(item_id):
    """单条数据详细内容采集"""
    item = CollectedData.query.get_or_404(item_id)
    
    if not item.url:
        return jsonify({'code': 1, 'msg': '该数据没有原始链接，无法采集'})
    
    # 优先使用绑定的规则
    rule = None
    bound_rule_ids = item.get_bound_rules()
    if bound_rule_ids:
        # 使用第一个绑定的规则
        rule = CrawlRule.query.filter(
            CrawlRule.id.in_(bound_rule_ids),
            CrawlRule.is_enabled == True
        ).first()
    
    # 如果没有绑定规则，则自动匹配
    if not rule:
        rule = match_crawl_rule(item.source)
        # 自动绑定匹配到的规则
        if rule:
            item.set_bound_rules([rule.id])
    
    rule_name = rule.name if rule else '通用规则'
    
    if rule:
        # 使用规则采集
        result = fetch_content_with_rule(item.url, rule)
    else:
        # 无规则，使用通用方法
        result = fetch_content_generic(item.url)
    
    if 'error' in result:
        return jsonify({'code': 1, 'msg': f'采集失败: {result["error"]}'})
    
    collected_title = result.get('title') or item.title
    collected_content = result.get('content', '')
    
    # 更新原始数据
    if result.get('title') and not item.title:
        item.title = result['title']
    if result.get('content'):
        item.content = result['content']
    
    item.is_deep_collected = True
    item.deep_collected_at = datetime.utcnow()
    
    # 保存到新的采集内容表
    # 检查是否已存在，存在则更新
    content_record = CollectedContent.query.filter_by(collected_data_id=item.id).first()
    if content_record:
        # 更新已有记录
        content_record.title = collected_title
        content_record.content = collected_content
        content_record.rule_name = rule_name
        content_record.content_length = len(collected_content) if collected_content else 0
        content_record.collected_at = datetime.utcnow()
    else:
        # 创建新记录
        content_record = CollectedContent(
            title=collected_title,
            content=collected_content,
            original_url=item.url,
            source=item.source,
            rule_name=rule_name,
            content_length=len(collected_content) if collected_content else 0,
            collected_data_id=item.id,
            user_id=current_user.id
        )
        db.session.add(content_record)
    
    # 如果规则有更新，保存规则
    if rule and result.get('rule_updated'):
        db.session.add(rule)
    
    db.session.commit()
    
    return jsonify({
        'code': 0,
        'msg': '采集成功' + ('' if rule else '（使用通用规则）'),
        'data': {
            'id': item.id,
            'title': collected_title,
            'content': collected_content[:500] + '...' if collected_content and len(collected_content) > 500 else collected_content,
            'content_length': len(collected_content) if collected_content else 0,
            'rule_name': rule_name,
            'rule_updated': result.get('rule_updated', False),
            'content_id': content_record.id
        }
    })


@main_bp.route('/api/warehouse/batch_deep_collect', methods=['POST'])
@login_required
def warehouse_batch_deep_collect():
    """批量详细内容采集"""
    data = request.get_json()
    ids = data.get('ids', [])
    
    if not ids:
        return jsonify({'code': 1, 'msg': '请选择要采集的数据'})
    
    items = CollectedData.query.filter(CollectedData.id.in_(ids)).all()
    
    success_count = 0
    fail_count = 0
    results = []
    rules_updated = set()
    
    for item in items:
        if not item.url:
            fail_count += 1
            results.append({'id': item.id, 'status': 'fail', 'msg': '无原始链接'})
            continue
        
        # 匹配规则
        rule = match_crawl_rule(item.source)
        rule_name = rule.name if rule else '通用规则'
        
        try:
            if rule:
                result = fetch_content_with_rule(item.url, rule)
            else:
                result = fetch_content_generic(item.url)
            
            if 'error' in result:
                fail_count += 1
                results.append({'id': item.id, 'status': 'fail', 'msg': result['error']})
                continue
            
            collected_title = result.get('title') or item.title
            collected_content = result.get('content', '')
            
            # 更新原始数据
            if result.get('title') and not item.title:
                item.title = result['title']
            if result.get('content'):
                item.content = result['content']
            
            item.is_deep_collected = True
            item.deep_collected_at = datetime.utcnow()
            
            # 保存到采集内容表
            content_record = CollectedContent.query.filter_by(collected_data_id=item.id).first()
            if content_record:
                content_record.title = collected_title
                content_record.content = collected_content
                content_record.rule_name = rule_name
                content_record.content_length = len(collected_content) if collected_content else 0
                content_record.collected_at = datetime.utcnow()
            else:
                content_record = CollectedContent(
                    title=collected_title,
                    content=collected_content,
                    original_url=item.url,
                    source=item.source,
                    rule_name=rule_name,
                    content_length=len(collected_content) if collected_content else 0,
                    collected_data_id=item.id,
                    user_id=current_user.id
                )
                db.session.add(content_record)
            
            if result.get('rule_updated') and rule:
                rules_updated.add(rule.id)
            
            success_count += 1
            results.append({
                'id': item.id, 
                'status': 'success', 
                'rule': rule_name
            })
            
        except Exception as e:
            fail_count += 1
            results.append({'id': item.id, 'status': 'fail', 'msg': str(e)})
    
    db.session.commit()
    
    return jsonify({
        'code': 0,
        'msg': f'采集完成：成功 {success_count} 条，失败 {fail_count} 条',
        'data': {
            'success': success_count,
            'fail': fail_count,
            'rules_updated': len(rules_updated),
            'details': results
        }
    })


# ==================== AI分析接口（预留） ====================

@main_bp.route('/api/ai/analyze', methods=['POST'])
@login_required
def ai_analyze_batch():
    """
    AI批量分析接口（预留）
    
    请求参数:
    - type: 分析类型 (sentiment/summary/keywords/report/trend/cluster)
    - data_ids: 要分析的数据ID列表
    
    返回:
    - code: 状态码
    - msg: 消息
    - data: 分析结果
    """
    data = request.get_json()
    analysis_type = data.get('type', '')
    data_ids = data.get('data_ids', [])
    
    # 验证分析类型
    valid_types = ['sentiment', 'summary', 'keywords', 'report', 'trend', 'cluster']
    if analysis_type not in valid_types:
        return jsonify({
            'code': 1,
            'msg': f'无效的分析类型，支持的类型: {", ".join(valid_types)}'
        })
    
    # TODO: 后期实现AI分析逻辑
    # 1. 情感分析 (sentiment): 分析文本正负面倾向
    # 2. 智能摘要 (summary): 生成内容摘要
    # 3. 关键词提取 (keywords): 提取核心关键词
    # 4. 生成报告 (report): 自动生成舆情分析报告
    # 5. 趋势分析 (trend): 分析舆情发展趋势
    # 6. 话题聚类 (cluster): 相似话题自动归类
    
    return jsonify({
        'code': 0,
        'msg': 'AI分析接口预留，功能即将上线',
        'data': {
            'type': analysis_type,
            'data_ids': data_ids,
            'status': 'pending',
            'result': None
        }
    })


@main_bp.route('/api/ai/analyze/<int:item_id>', methods=['POST'])
@login_required
def ai_analyze_single(item_id):
    """
    AI单条数据分析接口（预留）
    
    请求参数:
    - type: 分析类型 (sentiment/summary/keywords/report)
    
    返回:
    - code: 状态码
    - msg: 消息
    - data: 分析结果
    """
    # 获取数据
    item = CollectedData.query.get_or_404(item_id)
    
    data = request.get_json() or {}
    analysis_type = data.get('type', 'sentiment')
    
    # 验证分析类型
    valid_types = ['sentiment', 'summary', 'keywords', 'report']
    if analysis_type not in valid_types:
        return jsonify({
            'code': 1,
            'msg': f'无效的分析类型，支持的类型: {", ".join(valid_types)}'
        })
    
    # TODO: 后期实现AI分析逻辑
    # 可接入大语言模型API进行分析
    
    return jsonify({
        'code': 0,
        'msg': 'AI分析接口预留，功能即将上线',
        'data': {
            'item_id': item_id,
            'title': item.title,
            'type': analysis_type,
            'status': 'pending',
            'result': None
        }
    })


@main_bp.route('/api/ai/config', methods=['GET'])
@login_required
def ai_config():
    """
    获取AI配置信息（预留）
    
    返回可用的AI分析功能列表和配置
    """
    return jsonify({
        'code': 0,
        'data': {
            'enabled': False,  # AI功能是否启用
            'api_configured': False,  # API是否已配置
            'features': [
                {
                    'type': 'sentiment',
                    'name': '情感分析',
                    'description': '分析舆情正负面倾向',
                    'status': 'coming_soon'
                },
                {
                    'type': 'summary',
                    'name': '智能摘要',
                    'description': 'AI生成内容摘要',
                    'status': 'coming_soon'
                },
                {
                    'type': 'keywords',
                    'name': '关键词提取',
                    'description': '提取核心关键词',
                    'status': 'coming_soon'
                },
                {
                    'type': 'report',
                    'name': '生成报告',
                    'description': '自动生成舆情报告',
                    'status': 'coming_soon'
                },
                {
                    'type': 'trend',
                    'name': '趋势分析',
                    'description': '分析舆情发展趋势',
                    'status': 'coming_soon'
                },
                {
                    'type': 'cluster',
                    'name': '话题聚类',
                    'description': '相似话题自动归类',
                    'status': 'coming_soon'
                }
            ]
        }
    })
