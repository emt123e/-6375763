"""
认证模块 - 登录/退出路由
"""
from datetime import datetime
from flask import Blueprint, render_template, redirect, url_for, flash, request, jsonify
from flask_login import login_user, logout_user, login_required, current_user
from app import db
from app.models import User

# 创建认证蓝图
auth_bp = Blueprint('auth', __name__)


@auth_bp.route('/login', methods=['GET', 'POST'])
def login():
    """登录页面"""
    # 如果用户已登录，重定向到首页
    if current_user.is_authenticated:
        return redirect(url_for('main.index'))
    
    if request.method == 'POST':
        # 获取表单数据
        username = request.form.get('username', '').strip()
        password = request.form.get('password', '')
        remember = request.form.get('remember', False)
        
        # 验证用户
        user = User.query.filter_by(username=username).first()
        
        if user is None:
            return jsonify({'code': 1, 'msg': '用户名不存在'})
        
        if not user.check_password(password):
            return jsonify({'code': 1, 'msg': '密码错误'})
        
        if not user.is_active:
            return jsonify({'code': 1, 'msg': '账户已被禁用，请联系管理员'})
        
        # 登录用户
        login_user(user, remember=remember)
        
        # 更新最后登录时间
        user.last_login = datetime.utcnow()
        db.session.commit()
        
        return jsonify({'code': 0, 'msg': '登录成功', 'redirect': url_for('main.index')})
    
    return render_template('auth/login.html')


@auth_bp.route('/logout')
@login_required
def logout():
    """退出登录"""
    logout_user()
    return redirect(url_for('auth.login'))


@auth_bp.route('/api/current_user')
@login_required
def get_current_user():
    """获取当前登录用户信息"""
    return jsonify({
        'code': 0,
        'data': current_user.to_dict()
    })


@auth_bp.route('/api/change_password', methods=['POST'])
@login_required
def change_password():
    """修改密码"""
    data = request.get_json()
    old_password = data.get('old_password', '')
    new_password = data.get('new_password', '')
    confirm_password = data.get('confirm_password', '')
    
    if not old_password or not new_password:
        return jsonify({'code': 1, 'msg': '请填写完整信息'})
    
    if new_password != confirm_password:
        return jsonify({'code': 1, 'msg': '两次输入的新密码不一致'})
    
    if len(new_password) < 6:
        return jsonify({'code': 1, 'msg': '新密码长度不能少于6位'})
    
    if not current_user.check_password(old_password):
        return jsonify({'code': 1, 'msg': '原密码错误'})
    
    current_user.set_password(new_password)
    db.session.commit()
    
    return jsonify({'code': 0, 'msg': '密码修改成功'})
