"""
路由定义
"""
from flask import Blueprint, render_template, jsonify, request
from flask_login import login_required, current_user
from app import db
from app.models import SentimentReport, CollectedData
from app.crawler import fetch_news

# 创建蓝图
main_bp = Blueprint('main', __name__)


@main_bp.route('/')
@login_required
def index():
    """首页"""
    return render_template('index.html')


@main_bp.route('/api/health')
def health_check():
    """健康检查接口"""
    return jsonify({
        'status': 'ok',
        'message': '系统运行正常'
    })


@main_bp.route('/api/search', methods=['GET', 'POST'])
@login_required
def search_news():
    """搜索舆情数据"""
    if request.method == 'POST':
        data = request.get_json()
        keyword = data.get('keyword', '').strip()
        pages = data.get('pages', 1)
    else:
        keyword = request.args.get('keyword', '').strip()
        pages = request.args.get('pages', 1, type=int)
    
    if not keyword:
        return jsonify({
            'code': 1,
            'msg': '请输入搜索关键字'
        })
    
    try:
        # 调用爬虫获取数据
        results = fetch_news(keyword, pages=pages)
        
        return jsonify({
            'code': 0,
            'msg': 'success',
            'count': len(results),
            'keyword': keyword,
            'data': results
        })
    except Exception as e:
        return jsonify({
            'code': 1,
            'msg': f'搜索失败: {str(e)}'
        })


@main_bp.route('/api/search/save', methods=['POST'])
@login_required
def save_search_result():
    """保存搜索结果到舆情报告"""
    data = request.get_json()
    
    if not data or not data.get('title'):
        return jsonify({
            'code': 1,
            'msg': '标题不能为空'
        })
    
    report = SentimentReport(
        title=data.get('title'),
        content=data.get('summary', ''),
        source=data.get('source', ''),
        url=data.get('url', ''),
        cover=data.get('cover', ''),
        keywords=data.get('keyword', ''),
        sentiment='neutral'  # 默认中性，后续可通过AI分析
    )
    
    db.session.add(report)
    db.session.commit()
    
    return jsonify({
        'code': 0,
        'msg': '保存成功',
        'data': report.to_dict()
    })


@main_bp.route('/api/reports', methods=['GET'])
def get_reports():
    """获取舆情报告列表"""
    page = request.args.get('page', 1, type=int)
    per_page = request.args.get('limit', 10, type=int)
    
    pagination = SentimentReport.query.order_by(
        SentimentReport.created_at.desc()
    ).paginate(page=page, per_page=per_page, error_out=False)
    
    reports = [report.to_dict() for report in pagination.items]
    
    return jsonify({
        'code': 0,
        'msg': 'success',
        'count': pagination.total,
        'data': reports
    })


@main_bp.route('/api/reports', methods=['POST'])
def create_report():
    """创建舆情报告"""
    data = request.get_json()
    
    if not data or not data.get('title'):
        return jsonify({
            'code': 1,
            'msg': '标题不能为空'
        }), 400
    
    report = SentimentReport(
        title=data.get('title'),
        content=data.get('content'),
        source=data.get('source'),
        sentiment=data.get('sentiment'),
        keywords=data.get('keywords')
    )
    
    db.session.add(report)
    db.session.commit()
    
    return jsonify({
        'code': 0,
        'msg': '创建成功',
        'data': report.to_dict()
    })


@main_bp.route('/api/reports/<int:report_id>', methods=['GET'])
def get_report(report_id):
    """获取单个舆情报告"""
    report = SentimentReport.query.get_or_404(report_id)
    return jsonify({
        'code': 0,
        'msg': 'success',
        'data': report.to_dict()
    })


@main_bp.route('/api/reports/<int:report_id>', methods=['PUT'])
def update_report(report_id):
    """更新舆情报告"""
    report = SentimentReport.query.get_or_404(report_id)
    data = request.get_json()
    
    if data.get('title'):
        report.title = data['title']
    if data.get('content'):
        report.content = data['content']
    if data.get('source'):
        report.source = data['source']
    if data.get('sentiment'):
        report.sentiment = data['sentiment']
    if data.get('keywords'):
        report.keywords = data['keywords']
    
    db.session.commit()
    
    return jsonify({
        'code': 0,
        'msg': '更新成功',
        'data': report.to_dict()
    })


@main_bp.route('/api/reports/<int:report_id>', methods=['DELETE'])
def delete_report(report_id):
    """删除舆情报告"""
    report = SentimentReport.query.get_or_404(report_id)
    db.session.delete(report)
    db.session.commit()
    
    return jsonify({
        'code': 0,
        'msg': '删除成功'
    })


# ==================== 仓库功能 ====================

@main_bp.route('/warehouse')
@login_required
def warehouse():
    """仓库页面"""
    return render_template('warehouse.html')


@main_bp.route('/api/warehouse/save', methods=['POST'])
@login_required
def warehouse_save():
    """保存数据到仓库"""
    data = request.get_json()
    items = data.get('items', [])
    keyword = data.get('keyword', '')
    
    # 如果是单条数据
    if not items and data.get('title'):
        items = [data]
    
    if not items:
        return jsonify({'code': 1, 'msg': '没有要保存的数据'})
    
    saved_count = 0
    skipped_count = 0
    
    for item in items:
        # 检查是否已存在（根据URL去重）
        url = item.get('url', '')
        if url:
            existing = CollectedData.query.filter_by(url=url).first()
            if existing:
                skipped_count += 1
                continue
        
        collected = CollectedData(
            title=item.get('title', ''),
            summary=item.get('summary', ''),
            content=item.get('content', ''),
            cover=item.get('cover', ''),
            url=item.get('url', ''),
            source=item.get('source', ''),
            keyword=keyword,
            is_deep_collected=False,
            user_id=current_user.id
        )
        
        db.session.add(collected)
        saved_count += 1
    
    db.session.commit()
    
    if skipped_count > 0:
        return jsonify({
            'code': 0,
            'msg': f'保存成功！新增 {saved_count} 条，跳过 {skipped_count} 条重复数据'
        })
    
    return jsonify({
        'code': 0,
        'msg': f'成功保存 {saved_count} 条数据到仓库'
    })


@main_bp.route('/api/warehouse/list', methods=['GET'])
@login_required
def warehouse_list():
    """获取仓库数据列表"""
    page = request.args.get('page', 1, type=int)
    limit = request.args.get('limit', 10, type=int)
    keyword = request.args.get('keyword', '')
    
    query = CollectedData.query
    if keyword:
        query = query.filter(
            db.or_(
                CollectedData.title.like(f'%{keyword}%'),
                CollectedData.keyword.like(f'%{keyword}%'),
                CollectedData.source.like(f'%{keyword}%')
            )
        )
    
    pagination = query.order_by(CollectedData.created_at.desc()).paginate(
        page=page, per_page=limit, error_out=False
    )
    
    return jsonify({
        'code': 0,
        'msg': 'success',
        'count': pagination.total,
        'data': [item.to_dict() for item in pagination.items]
    })


@main_bp.route('/api/warehouse/<int:item_id>', methods=['GET'])
@login_required
def warehouse_get(item_id):
    """获取仓库单条数据"""
    item = CollectedData.query.get_or_404(item_id)
    return jsonify({
        'code': 0,
        'data': item.to_dict()
    })


@main_bp.route('/api/warehouse/<int:item_id>', methods=['DELETE'])
@login_required
def warehouse_delete(item_id):
    """删除仓库数据"""
    item = CollectedData.query.get_or_404(item_id)
    db.session.delete(item)
    db.session.commit()
    return jsonify({'code': 0, 'msg': '删除成功'})


@main_bp.route('/api/warehouse/batch_delete', methods=['POST'])
@login_required
def warehouse_batch_delete():
    """批量删除仓库数据"""
    data = request.get_json()
    ids = data.get('ids', [])
    
    if not ids:
        return jsonify({'code': 1, 'msg': '请选择要删除的数据'})
    
    CollectedData.query.filter(CollectedData.id.in_(ids)).delete(synchronize_session=False)
    db.session.commit()
    
    return jsonify({'code': 0, 'msg': f'成功删除 {len(ids)} 条数据'})


@main_bp.route('/api/warehouse/stats', methods=['GET'])
@login_required
def warehouse_stats():
    """获取仓库统计数据"""
    total = CollectedData.query.count()
    deep_collected = CollectedData.query.filter_by(is_deep_collected=True).count()
    
    return jsonify({
        'code': 0,
        'data': {
            'total': total,
            'deep_collected': deep_collected,
            'pending': total - deep_collected
        }
    })
