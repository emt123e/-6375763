"""
Flask应用工厂
"""
from flask import Flask, redirect, url_for, request
from flask_sqlalchemy import SQLAlchemy
from flask_migrate import Migrate
from flask_login import LoginManager, current_user
from config import config

# 初始化扩展
db = SQLAlchemy()
migrate = Migrate()
login_manager = LoginManager()
login_manager.login_view = 'auth.login'
login_manager.login_message = '请先登录'
login_manager.login_message_category = 'warning'


def create_app(config_name='default'):
    """
    应用工厂函数
    :param config_name: 配置名称
    :return: Flask应用实例
    """
    app = Flask(__name__,
                static_folder='../static',
                template_folder='../templates')
    
    # 加载配置
    app.config.from_object(config[config_name])
    
    # 初始化扩展
    db.init_app(app)
    migrate.init_app(app, db)
    login_manager.init_app(app)
    
    # 用户加载回调
    from app.models import User
    
    @login_manager.user_loader
    def load_user(user_id):
        return User.query.get(int(user_id))
    
    # 未登录时的处理
    @login_manager.unauthorized_handler
    def unauthorized():
        if request.is_json or request.headers.get('X-Requested-With') == 'XMLHttpRequest':
            from flask import jsonify
            return jsonify({'code': 401, 'msg': '请先登录'}), 401
        return redirect(url_for('auth.login'))
    
    # 注册蓝图
    from app.routes import main_bp
    from app.auth import auth_bp
    from app.admin import admin_bp
    
    app.register_blueprint(main_bp)
    app.register_blueprint(auth_bp)
    app.register_blueprint(admin_bp)
    
    # 注入全局模板变量
    @app.context_processor
    def inject_globals():
        from app.models import SystemSetting
        return {
            'app_name': SystemSetting.get_setting('app_name', '政企智能舆情分析系统'),
            'app_logo': SystemSetting.get_setting('app_logo', ''),
            'app_copyright': SystemSetting.get_setting('app_copyright', 'Copyright © 2024 政企智能舆情分析系统 All Rights Reserved')
        }
    
    # 创建数据库表并初始化数据
    with app.app_context():
        db.create_all()
        
        # 初始化角色和管理员
        from app.models import Role, User, SystemSetting
        Role.init_roles()
        User.init_admin()
        SystemSetting.init_settings()
    
    return app
