"""
数据库模型定义
"""
from datetime import datetime
from werkzeug.security import generate_password_hash, check_password_hash
from flask_login import UserMixin
from app import db


class Role(db.Model):
    """角色模型"""
    __tablename__ = 'roles'
    
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(64), unique=True, nullable=False)
    description = db.Column(db.String(200))
    permissions = db.Column(db.String(500))  # 权限列表，JSON格式
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    # 关联用户
    users = db.relationship('User', backref='role', lazy='dynamic')
    
    def __repr__(self):
        return f'<Role {self.name}>'
    
    def to_dict(self):
        return {
            'id': self.id,
            'name': self.name,
            'description': self.description,
            'permissions': self.permissions,
            'created_at': self.created_at.strftime('%Y-%m-%d %H:%M:%S') if self.created_at else None
        }
    
    @staticmethod
    def init_roles():
        """初始化默认角色"""
        roles = [
            {'name': 'admin', 'description': '管理员', 'permissions': 'all'},
            {'name': 'user', 'description': '普通用户', 'permissions': 'view_dashboard,view_reports'}
        ]
        for r in roles:
            role = Role.query.filter_by(name=r['name']).first()
            if role is None:
                role = Role(name=r['name'], description=r['description'], permissions=r['permissions'])
                db.session.add(role)
        db.session.commit()


class User(UserMixin, db.Model):
    """用户模型"""
    __tablename__ = 'users'
    
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(64), unique=True, nullable=False, index=True)
    password_hash = db.Column(db.String(256))
    email = db.Column(db.String(120), unique=True, index=True)
    realname = db.Column(db.String(64))  # 真实姓名
    phone = db.Column(db.String(20))  # 手机号
    avatar = db.Column(db.String(200))  # 头像
    is_active = db.Column(db.Boolean, default=True)  # 是否启用
    role_id = db.Column(db.Integer, db.ForeignKey('roles.id'))  # 角色ID
    last_login = db.Column(db.DateTime)  # 最后登录时间
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    def __repr__(self):
        return f'<User {self.username}>'
    
    def set_password(self, password):
        """设置密码（加密存储）"""
        self.password_hash = generate_password_hash(password)
    
    def check_password(self, password):
        """验证密码"""
        return check_password_hash(self.password_hash, password)
    
    def is_admin(self):
        """判断是否为管理员"""
        return self.role and self.role.name == 'admin'
    
    def has_permission(self, permission):
        """检查是否有某个权限"""
        if not self.role:
            return False
        if self.role.permissions == 'all':
            return True
        return permission in self.role.permissions.split(',')
    
    def to_dict(self):
        return {
            'id': self.id,
            'username': self.username,
            'email': self.email,
            'realname': self.realname,
            'phone': self.phone,
            'avatar': self.avatar,
            'is_active': self.is_active,
            'role_id': self.role_id,
            'role_name': self.role.description if self.role else None,
            'last_login': self.last_login.strftime('%Y-%m-%d %H:%M:%S') if self.last_login else None,
            'created_at': self.created_at.strftime('%Y-%m-%d %H:%M:%S') if self.created_at else None
        }
    
    @staticmethod
    def init_admin():
        """初始化管理员账户"""
        admin_role = Role.query.filter_by(name='admin').first()
        if admin_role:
            admin = User.query.filter_by(username='admin').first()
            if admin is None:
                admin = User(
                    username='admin',
                    email='admin@example.com',
                    realname='系统管理员',
                    role_id=admin_role.id,
                    is_active=True
                )
                admin.set_password('admin123')
                db.session.add(admin)
                db.session.commit()


class SystemSetting(db.Model):
    """系统设置模型"""
    __tablename__ = 'system_settings'
    
    id = db.Column(db.Integer, primary_key=True)
    key = db.Column(db.String(64), unique=True, nullable=False, index=True)
    value = db.Column(db.Text)
    description = db.Column(db.String(200))
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    def __repr__(self):
        return f'<SystemSetting {self.key}>'
    
    def to_dict(self):
        return {
            'id': self.id,
            'key': self.key,
            'value': self.value,
            'description': self.description,
            'updated_at': self.updated_at.strftime('%Y-%m-%d %H:%M:%S') if self.updated_at else None
        }
    
    @staticmethod
    def get_setting(key, default=None):
        """获取系统设置值"""
        setting = SystemSetting.query.filter_by(key=key).first()
        return setting.value if setting else default
    
    @staticmethod
    def set_setting(key, value, description=None):
        """设置系统设置值"""
        setting = SystemSetting.query.filter_by(key=key).first()
        if setting:
            setting.value = value
            if description:
                setting.description = description
        else:
            setting = SystemSetting(key=key, value=value, description=description)
            db.session.add(setting)
        db.session.commit()
        return setting
    
    @staticmethod
    def init_settings():
        """初始化默认系统设置"""
        default_settings = [
            {'key': 'app_name', 'value': '政企智能舆情分析系统', 'description': '应用名称'},
            {'key': 'app_logo', 'value': '', 'description': '应用LOGO路径'},
            {'key': 'app_copyright', 'value': 'Copyright © 2024 政企智能舆情分析系统 All Rights Reserved', 'description': '版权信息'}
        ]
        for s in default_settings:
            existing = SystemSetting.query.filter_by(key=s['key']).first()
            if not existing:
                setting = SystemSetting(**s)
                db.session.add(setting)
        db.session.commit()


class CollectedData(db.Model):
    """采集数据模型"""
    __tablename__ = 'collected_data'
    
    id = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String(500), nullable=False)  # 标题
    summary = db.Column(db.Text)  # 摘要
    content = db.Column(db.Text)  # 深度采集的正文内容
    cover = db.Column(db.String(500))  # 封面图片
    url = db.Column(db.String(1000))  # 原始链接
    source = db.Column(db.String(200))  # 来源
    keyword = db.Column(db.String(200))  # 采集关键词
    is_deep_collected = db.Column(db.Boolean, default=False)  # 是否已深度采集
    deep_collected_at = db.Column(db.DateTime)  # 深度采集时间
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    # 外键关联
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'))
    user = db.relationship('User', backref=db.backref('collected_data', lazy='dynamic'))
    
    def __repr__(self):
        return f'<CollectedData {self.title[:30]}>'
    
    def to_dict(self):
        return {
            'id': self.id,
            'title': self.title,
            'summary': self.summary,
            'content': self.content,
            'cover': self.cover,
            'url': self.url,
            'source': self.source,
            'keyword': self.keyword,
            'is_deep_collected': self.is_deep_collected,
            'deep_collected_at': self.deep_collected_at.strftime('%Y-%m-%d %H:%M:%S') if self.deep_collected_at else None,
            'created_at': self.created_at.strftime('%Y-%m-%d %H:%M:%S') if self.created_at else None
        }


class SentimentReport(db.Model):
    """舆情报告模型"""
    __tablename__ = 'sentiment_reports'
    
    id = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String(200), nullable=False)
    content = db.Column(db.Text)
    source = db.Column(db.String(100))  # 来源
    url = db.Column(db.String(500))  # 原始链接
    cover = db.Column(db.String(500))  # 封面图片
    sentiment = db.Column(db.String(20))  # 情感倾向: positive/negative/neutral
    keywords = db.Column(db.String(500))  # 关键词
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # 外键关联
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'))
    user = db.relationship('User', backref=db.backref('reports', lazy='dynamic'))
    
    def __repr__(self):
        return f'<SentimentReport {self.title}>'
    
    def to_dict(self):
        """转换为字典"""
        return {
            'id': self.id,
            'title': self.title,
            'content': self.content,
            'source': self.source,
            'url': self.url,
            'cover': self.cover,
            'sentiment': self.sentiment,
            'keywords': self.keywords,
            'created_at': self.created_at.strftime('%Y-%m-%d %H:%M:%S') if self.created_at else None,
            'updated_at': self.updated_at.strftime('%Y-%m-%d %H:%M:%S') if self.updated_at else None
        }
