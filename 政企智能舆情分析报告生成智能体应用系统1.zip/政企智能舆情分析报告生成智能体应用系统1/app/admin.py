"""
后台管理模块 - 用户管理、角色管理、系统设置
"""
import os
from functools import wraps
from flask import Blueprint, render_template, request, jsonify, current_app
from flask_login import login_required, current_user
from werkzeug.utils import secure_filename
from app import db
from app.models import User, Role, SystemSetting, CollectedData
from app.crawler import fetch_news, BaiduNewsCrawler

# 创建后台管理蓝图
admin_bp = Blueprint('admin', __name__, url_prefix='/admin')


def admin_required(f):
    """管理员权限装饰器"""
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if not current_user.is_authenticated:
            return jsonify({'code': 401, 'msg': '请先登录'})
        if not current_user.is_admin():
            return jsonify({'code': 403, 'msg': '权限不足，需要管理员权限'})
        return f(*args, **kwargs)
    return decorated_function


# ==================== 页面路由 ====================

@admin_bp.route('/')
@login_required
@admin_required
def index():
    """后台管理首页"""
    return render_template('admin/index.html')


@admin_bp.route('/users')
@login_required
@admin_required
def users_page():
    """用户管理页面"""
    return render_template('admin/users.html')


@admin_bp.route('/roles')
@login_required
@admin_required
def roles_page():
    """角色管理页面"""
    return render_template('admin/roles.html')


@admin_bp.route('/settings')
@login_required
@admin_required
def settings_page():
    """系统设置页面"""
    return render_template('admin/settings.html')


# ==================== 用户管理API ====================

@admin_bp.route('/api/users', methods=['GET'])
@login_required
@admin_required
def get_users():
    """获取用户列表"""
    page = request.args.get('page', 1, type=int)
    limit = request.args.get('limit', 10, type=int)
    username = request.args.get('username', '')
    
    query = User.query
    if username:
        query = query.filter(User.username.like(f'%{username}%'))
    
    pagination = query.order_by(User.created_at.desc()).paginate(
        page=page, per_page=limit, error_out=False
    )
    
    users = [user.to_dict() for user in pagination.items]
    
    return jsonify({
        'code': 0,
        'msg': 'success',
        'count': pagination.total,
        'data': users
    })


@admin_bp.route('/api/users', methods=['POST'])
@login_required
@admin_required
def create_user():
    """创建用户"""
    data = request.get_json()
    
    username = data.get('username', '').strip()
    password = data.get('password', '')
    email = data.get('email', '').strip()
    realname = data.get('realname', '').strip()
    phone = data.get('phone', '').strip()
    role_id = data.get('role_id')
    is_active = data.get('is_active', True)
    
    if not username:
        return jsonify({'code': 1, 'msg': '用户名不能为空'})
    
    if not password:
        return jsonify({'code': 1, 'msg': '密码不能为空'})
    
    if len(password) < 6:
        return jsonify({'code': 1, 'msg': '密码长度不能少于6位'})
    
    # 检查用户名是否已存在
    if User.query.filter_by(username=username).first():
        return jsonify({'code': 1, 'msg': '用户名已存在'})
    
    # 检查邮箱是否已存在
    if email and User.query.filter_by(email=email).first():
        return jsonify({'code': 1, 'msg': '邮箱已被使用'})
    
    user = User(
        username=username,
        email=email if email else None,
        realname=realname,
        phone=phone,
        role_id=role_id,
        is_active=is_active
    )
    user.set_password(password)
    
    db.session.add(user)
    db.session.commit()
    
    return jsonify({'code': 0, 'msg': '创建成功', 'data': user.to_dict()})


@admin_bp.route('/api/users/<int:user_id>', methods=['GET'])
@login_required
@admin_required
def get_user(user_id):
    """获取单个用户"""
    user = User.query.get_or_404(user_id)
    return jsonify({'code': 0, 'data': user.to_dict()})


@admin_bp.route('/api/users/<int:user_id>', methods=['PUT'])
@login_required
@admin_required
def update_user(user_id):
    """更新用户"""
    user = User.query.get_or_404(user_id)
    data = request.get_json()
    
    # 不允许修改admin用户的用户名
    if user.username == 'admin' and data.get('username') != 'admin':
        return jsonify({'code': 1, 'msg': '不能修改管理员用户名'})
    
    username = data.get('username', '').strip()
    if username and username != user.username:
        if User.query.filter_by(username=username).first():
            return jsonify({'code': 1, 'msg': '用户名已存在'})
        user.username = username
    
    email = data.get('email', '').strip()
    if email and email != user.email:
        if User.query.filter_by(email=email).first():
            return jsonify({'code': 1, 'msg': '邮箱已被使用'})
        user.email = email
    
    if 'realname' in data:
        user.realname = data['realname']
    if 'phone' in data:
        user.phone = data['phone']
    if 'role_id' in data:
        # 不允许修改admin用户的角色
        if user.username != 'admin':
            user.role_id = data['role_id']
    if 'is_active' in data:
        # 不允许禁用admin用户
        if user.username != 'admin':
            user.is_active = data['is_active']
    
    # 如果提供了新密码，则更新密码
    password = data.get('password', '')
    if password:
        if len(password) < 6:
            return jsonify({'code': 1, 'msg': '密码长度不能少于6位'})
        user.set_password(password)
    
    db.session.commit()
    
    return jsonify({'code': 0, 'msg': '更新成功', 'data': user.to_dict()})


@admin_bp.route('/api/users/<int:user_id>', methods=['DELETE'])
@login_required
@admin_required
def delete_user(user_id):
    """删除用户"""
    user = User.query.get_or_404(user_id)
    
    # 不允许删除admin用户
    if user.username == 'admin':
        return jsonify({'code': 1, 'msg': '不能删除管理员账户'})
    
    # 不允许删除自己
    if user.id == current_user.id:
        return jsonify({'code': 1, 'msg': '不能删除当前登录账户'})
    
    db.session.delete(user)
    db.session.commit()
    
    return jsonify({'code': 0, 'msg': '删除成功'})


# ==================== 角色管理API ====================

@admin_bp.route('/api/roles', methods=['GET'])
@login_required
@admin_required
def get_roles():
    """获取角色列表"""
    page = request.args.get('page', 1, type=int)
    limit = request.args.get('limit', 10, type=int)
    
    pagination = Role.query.order_by(Role.id).paginate(
        page=page, per_page=limit, error_out=False
    )
    
    roles = [role.to_dict() for role in pagination.items]
    
    return jsonify({
        'code': 0,
        'msg': 'success',
        'count': pagination.total,
        'data': roles
    })


@admin_bp.route('/api/roles/all', methods=['GET'])
@login_required
def get_all_roles():
    """获取所有角色（用于下拉选择）"""
    roles = Role.query.all()
    return jsonify({
        'code': 0,
        'data': [role.to_dict() for role in roles]
    })


@admin_bp.route('/api/roles', methods=['POST'])
@login_required
@admin_required
def create_role():
    """创建角色"""
    data = request.get_json()
    
    name = data.get('name', '').strip()
    description = data.get('description', '').strip()
    permissions = data.get('permissions', '')
    
    if not name:
        return jsonify({'code': 1, 'msg': '角色名称不能为空'})
    
    if Role.query.filter_by(name=name).first():
        return jsonify({'code': 1, 'msg': '角色名称已存在'})
    
    role = Role(name=name, description=description, permissions=permissions)
    db.session.add(role)
    db.session.commit()
    
    return jsonify({'code': 0, 'msg': '创建成功', 'data': role.to_dict()})


@admin_bp.route('/api/roles/<int:role_id>', methods=['PUT'])
@login_required
@admin_required
def update_role(role_id):
    """更新角色"""
    role = Role.query.get_or_404(role_id)
    data = request.get_json()
    
    # 不允许修改admin和user角色的名称
    if role.name in ['admin', 'user'] and data.get('name') != role.name:
        return jsonify({'code': 1, 'msg': '不能修改系统内置角色名称'})
    
    name = data.get('name', '').strip()
    if name and name != role.name:
        if Role.query.filter_by(name=name).first():
            return jsonify({'code': 1, 'msg': '角色名称已存在'})
        role.name = name
    
    if 'description' in data:
        role.description = data['description']
    if 'permissions' in data:
        role.permissions = data['permissions']
    
    db.session.commit()
    
    return jsonify({'code': 0, 'msg': '更新成功', 'data': role.to_dict()})


@admin_bp.route('/api/roles/<int:role_id>', methods=['DELETE'])
@login_required
@admin_required
def delete_role(role_id):
    """删除角色"""
    role = Role.query.get_or_404(role_id)
    
    # 不允许删除系统内置角色
    if role.name in ['admin', 'user']:
        return jsonify({'code': 1, 'msg': '不能删除系统内置角色'})
    
    # 检查是否有用户使用此角色
    if role.users.count() > 0:
        return jsonify({'code': 1, 'msg': '该角色下还有用户，无法删除'})
    
    db.session.delete(role)
    db.session.commit()
    
    return jsonify({'code': 0, 'msg': '删除成功'})


# ==================== 系统设置API ====================

@admin_bp.route('/api/settings', methods=['GET'])
@login_required
@admin_required
def get_settings():
    """获取系统设置"""
    settings = SystemSetting.query.all()
    return jsonify({
        'code': 0,
        'data': [s.to_dict() for s in settings]
    })


@admin_bp.route('/api/settings', methods=['POST'])
@login_required
@admin_required
def update_settings():
    """更新系统设置"""
    data = request.get_json()
    
    for key, value in data.items():
        SystemSetting.set_setting(key, value)
    
    return jsonify({'code': 0, 'msg': '保存成功'})


@admin_bp.route('/api/settings/upload_logo', methods=['POST'])
@login_required
@admin_required
def upload_logo():
    """上传LOGO"""
    if 'file' not in request.files:
        return jsonify({'code': 1, 'msg': '没有上传文件'})
    
    file = request.files['file']
    if file.filename == '':
        return jsonify({'code': 1, 'msg': '没有选择文件'})
    
    # 检查文件类型
    allowed_extensions = {'png', 'jpg', 'jpeg', 'gif', 'svg'}
    ext = file.filename.rsplit('.', 1)[1].lower() if '.' in file.filename else ''
    if ext not in allowed_extensions:
        return jsonify({'code': 1, 'msg': '不支持的文件格式'})
    
    # 保存文件
    filename = secure_filename(f'logo.{ext}')
    upload_folder = os.path.join(current_app.static_folder, 'uploads')
    os.makedirs(upload_folder, exist_ok=True)
    
    filepath = os.path.join(upload_folder, filename)
    file.save(filepath)
    
    # 更新系统设置
    logo_url = f'/static/uploads/{filename}'
    SystemSetting.set_setting('app_logo', logo_url)
    
    return jsonify({'code': 0, 'msg': '上传成功', 'data': {'url': logo_url}})


# ==================== 数据采集管理 ====================

@admin_bp.route('/collect')
@login_required
@admin_required
def collect_page():
    """数据采集管理页面"""
    return render_template('admin/collect.html')


@admin_bp.route('/api/collect/search', methods=['POST'])
@login_required
@admin_required
def collect_search():
    """搜索采集数据"""
    data = request.get_json()
    keyword = data.get('keyword', '').strip()
    pages = data.get('pages', 1)
    
    if not keyword:
        return jsonify({'code': 1, 'msg': '请输入搜索关键词'})
    
    try:
        # 调用爬虫获取数据
        results = fetch_news(keyword, pages=pages)
        
        return jsonify({
            'code': 0,
            'msg': 'success',
            'count': len(results),
            'keyword': keyword,
            'data': results
        })
    except Exception as e:
        return jsonify({'code': 1, 'msg': f'采集失败: {str(e)}'})


@admin_bp.route('/api/collect/deep', methods=['POST'])
@login_required
@admin_required
def collect_deep():
    """深度采集单条数据 - 通过原地址进入详细页面采集详细内容"""
    from datetime import datetime
    import requests
    from bs4 import BeautifulSoup
    import re
    
    data = request.get_json()
    url = data.get('url', '').strip()
    
    if not url:
        return jsonify({'code': 1, 'msg': '缺少URL参数'})
    
    try:
        # 发送请求获取页面内容
        headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
            'Accept-Language': 'zh-CN,zh;q=0.9,en;q=0.8',
            'Connection': 'keep-alive'
        }
        response = requests.get(url, headers=headers, timeout=20, allow_redirects=True)
        response.encoding = response.apparent_encoding or 'utf-8'
        
        # 解析页面内容
        soup = BeautifulSoup(response.text, 'html.parser')
        
        # 提取页面标题
        page_title = ''
        title_elem = soup.find('title')
        if title_elem:
            page_title = title_elem.get_text(strip=True)
        
        # 尝试从h1标签获取更精确的标题
        h1_elem = soup.find('h1')
        if h1_elem:
            page_title = h1_elem.get_text(strip=True) or page_title
        
        # 移除脚本、样式和无关元素
        for elem in soup(['script', 'style', 'nav', 'header', 'footer', 'aside', 
                          'iframe', 'noscript', 'form', 'button', 'input']):
            elem.decompose()
        
        # 移除注释
        for comment in soup.find_all(string=lambda text: isinstance(text, type(soup.new_string('')))):
            if isinstance(comment, type(soup.new_string(''))) and comment.parent and comment.parent.name is None:
                comment.extract()
        
        # 尝试提取正文内容
        content = ''
        
        # 常见的正文容器选择器（按优先级排序）
        content_selectors = [
            # 新闻网站常用
            '.article-content', '.news-content', '.post-content',
            '.article-body', '.news-body', '.post-body',
            '#article-content', '#news-content', '#post-content',
            # 通用选择器
            'article', '.article', '#article',
            '.content', '#content', '.main-content', '#main-content',
            '.entry-content', '.text-content', '.body-content',
            # 百度百家号等
            '.index-module_articleWrap', '.article-holder',
            # 微信公众号
            '#js_content', '.rich_media_content',
            # 其他
            '[itemprop="articleBody"]', '[role="main"]',
            '.detail-content', '.news-detail', '.article-detail'
        ]
        
        for selector in content_selectors:
            content_elem = soup.select_one(selector)
            if content_elem:
                # 获取所有段落文本
                paragraphs = content_elem.find_all(['p', 'div', 'span'])
                texts = []
                for p in paragraphs:
                    text = p.get_text(strip=True)
                    # 过滤太短的文本和广告相关文本
                    if len(text) > 15 and not re.search(r'(广告|推荐阅读|相关文章|点击查看|分享到)', text):
                        texts.append(text)
                if texts:
                    content = '\n\n'.join(texts)
                    break
        
        # 如果没找到，尝试获取body中的主要文本
        if not content:
            body = soup.find('body')
            if body:
                paragraphs = body.find_all('p')
                texts = []
                for p in paragraphs:
                    text = p.get_text(strip=True)
                    if len(text) > 25:
                        texts.append(text)
                content = '\n\n'.join(texts[:30])  # 限制段落数量
        
        # 清理内容中的多余空白
        if content:
            content = re.sub(r'\n{3,}', '\n\n', content)
            content = re.sub(r' {2,}', ' ', content)
        
        if not content:
            content = '无法提取正文内容，请直接访问原文链接查看。'
        
        return jsonify({
            'code': 0,
            'msg': '深度采集成功',
            'data': {
                'title': page_title,
                'content': content[:8000],  # 限制内容长度
                'url': response.url,  # 返回最终URL（可能有重定向）
                'collected_at': datetime.utcnow().strftime('%Y-%m-%d %H:%M:%S')
            }
        })
    except requests.Timeout:
        return jsonify({'code': 1, 'msg': '请求超时，目标网站响应过慢'})
    except requests.RequestException as e:
        return jsonify({'code': 1, 'msg': f'请求失败: {str(e)}'})
    except Exception as e:
        return jsonify({'code': 1, 'msg': f'深度采集失败: {str(e)}'})


@admin_bp.route('/api/collect/save', methods=['POST'])
@login_required
@admin_required
def collect_save():
    """保存采集数据到数据库"""
    data = request.get_json()
    items = data.get('items', [])
    keyword = data.get('keyword', '')
    
    if not items:
        return jsonify({'code': 1, 'msg': '没有要保存的数据'})
    
    saved_count = 0
    skipped_count = 0
    
    for item in items:
        # 检查是否已存在（根据URL去重）
        existing = CollectedData.query.filter_by(url=item.get('url')).first()
        if existing:
            skipped_count += 1
            continue
        
        collected = CollectedData(
            title=item.get('title', ''),
            summary=item.get('summary', ''),
            content=item.get('content', ''),
            cover=item.get('cover', ''),
            url=item.get('url', ''),
            source=item.get('source', ''),
            keyword=keyword,
            is_deep_collected=item.get('is_deep_collected', False),
            user_id=current_user.id
        )
        
        if item.get('is_deep_collected'):
            from datetime import datetime
            collected.deep_collected_at = datetime.utcnow()
        
        db.session.add(collected)
        saved_count += 1
    
    db.session.commit()
    
    return jsonify({
        'code': 0,
        'msg': f'保存成功！新增 {saved_count} 条，跳过 {skipped_count} 条重复数据'
    })


@admin_bp.route('/api/collect/list', methods=['GET'])
@login_required
@admin_required
def collect_list():
    """获取已保存的采集数据列表"""
    page = request.args.get('page', 1, type=int)
    limit = request.args.get('limit', 10, type=int)
    keyword = request.args.get('keyword', '')
    
    query = CollectedData.query
    if keyword:
        query = query.filter(
            db.or_(
                CollectedData.title.like(f'%{keyword}%'),
                CollectedData.keyword.like(f'%{keyword}%')
            )
        )
    
    pagination = query.order_by(CollectedData.created_at.desc()).paginate(
        page=page, per_page=limit, error_out=False
    )
    
    return jsonify({
        'code': 0,
        'msg': 'success',
        'count': pagination.total,
        'data': [item.to_dict() for item in pagination.items]
    })


@admin_bp.route('/api/collect/<int:item_id>', methods=['DELETE'])
@login_required
@admin_required
def collect_delete(item_id):
    """删除采集数据"""
    item = CollectedData.query.get_or_404(item_id)
    db.session.delete(item)
    db.session.commit()
    return jsonify({'code': 0, 'msg': '删除成功'})


@admin_bp.route('/api/collect/batch_delete', methods=['POST'])
@login_required
@admin_required
def collect_batch_delete():
    """批量删除采集数据"""
    data = request.get_json()
    ids = data.get('ids', [])
    
    if not ids:
        return jsonify({'code': 1, 'msg': '请选择要删除的数据'})
    
    CollectedData.query.filter(CollectedData.id.in_(ids)).delete(synchronize_session=False)
    db.session.commit()
    
    return jsonify({'code': 0, 'msg': f'成功删除 {len(ids)} 条数据'})
