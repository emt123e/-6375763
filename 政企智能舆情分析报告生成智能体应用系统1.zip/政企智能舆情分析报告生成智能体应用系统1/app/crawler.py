"""
数据抓取模块 - 百度新闻舆情数据采集
"""
import re
import json
import requests
from urllib.parse import quote
from bs4 import BeautifulSoup, Comment
from typing import List, Dict, Optional
import time
import random


class BaiduNewsCrawler:
    """百度新闻爬虫"""
    
    # 多个User-Agent轮换
    USER_AGENTS = [
        'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
        'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/119.0.0.0 Safari/537.36',
        'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:121.0) Gecko/20100101 Firefox/121.0',
        'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36 Edg/120.0.0.0',
        'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
    ]
    
    def __init__(self):
        self.base_url = "https://www.baidu.com/s"
        self.session = requests.Session()
        self._update_headers()
    
    def _update_headers(self):
        """更新请求头，随机选择User-Agent"""
        self.headers = {
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8',
            'Accept-Language': 'zh-CN,zh;q=0.9',
            'Connection': 'keep-alive',
            'User-Agent': random.choice(self.USER_AGENTS)
        }
        self.session.headers.update(self.headers)
    
    def _init_cookies(self):
        """初始化Cookie，先访问百度首页获取Cookie"""
        try:
            self.session.get('https://www.baidu.com/', timeout=10)
            time.sleep(random.uniform(0.5, 1))
        except:
            pass
    
    def search(self, keyword: str, page: int = 1, retry: int = 2) -> List[Dict]:
        """
        搜索百度新闻
        
        :param keyword: 搜索关键字
        :param page: 页码，从1开始
        :return: 新闻列表
        """
        results = []
        
        try:
            # 构建请求参数
            params = {
                'rtt': '1',
                'bsst': '1',
                'cl': '2',
                'tn': 'news',
                'rsv_dl': 'ns_pc',
                'word': keyword,
                'pn': (page - 1) * 10  # 百度分页参数
            }
            
            # 随机延迟，避免请求过快
            time.sleep(random.uniform(1, 2))
            
            # 发送请求
            response = self.session.get(
                self.base_url,
                params=params,
                timeout=15
            )
            response.raise_for_status()
            response.encoding = 'utf-8'
            
            # 检查是否触发验证
            if '百度安全验证' in response.text or len(response.text) < 5000:
                if retry > 0:
                    # 重新初始化Cookie并重试
                    self._update_headers()
                    self._init_cookies()
                    time.sleep(random.uniform(2, 4))
                    return self.search(keyword, page, retry - 1)
                else:
                    print("触发百度安全验证，请稍后重试")
                    return []
            
            # 解析HTML
            results = self._parse_html(response.text)
            
        except requests.RequestException as e:
            print(f"请求错误: {e}")
        except Exception as e:
            print(f"解析错误: {e}")
        
        return results
    
    def _parse_html(self, html: str) -> List[Dict]:
        """
        解析HTML提取新闻数据
        
        :param html: HTML内容
        :return: 新闻列表
        """
        results = []
        soup = BeautifulSoup(html, 'html.parser')
        
        # 查找新闻结果容器 - 百度新闻使用c-container类
        news_items = soup.find_all('div', class_=re.compile(r'c-container'))
        
        for item in news_items:
            try:
                news_data = self._extract_news_item(item)
                if news_data and news_data.get('title'):
                    results.append(news_data)
            except Exception as e:
                print(f"提取新闻项错误: {e}")
                continue
        
        return results
    
    def _clean_html_tags(self, text: str) -> str:
        """清理HTML标签"""
        if not text:
            return ''
        # 移除<em>等HTML标签
        return re.sub(r'<[^>]+>', '', text).strip()
    
    def _extract_news_item(self, item) -> Optional[Dict]:
        """
        提取单条新闻数据 - 从s-data属性中提取JSON数据
        
        :param item: BeautifulSoup元素
        :return: 新闻数据字典
        """
        news_data = {
            'title': '',       # 标题
            'summary': '',     # 概要
            'cover': '',       # 封面图片
            'url': '',         # 原始URL
            'source': ''       # 来源
        }
        
        # 方法1: 从s-data注释中提取JSON数据（百度新闻主要方式）
        comments = item.find_all(string=lambda text: isinstance(text, Comment))
        for comment in comments:
            if 's-data:' in comment:
                match = re.search(r's-data:(\{.*\})', comment, re.DOTALL)
                if match:
                    try:
                        s_data = json.loads(match.group(1))
                        # 从JSON数据提取信息
                        news_data['title'] = self._clean_html_tags(s_data.get('title', ''))
                        news_data['url'] = s_data.get('titleUrl', '')
                        news_data['summary'] = self._clean_html_tags(s_data.get('summary', ''))
                        news_data['source'] = s_data.get('sourceName', '') or s_data.get('rtses', '')
                        news_data['cover'] = s_data.get('leftImgSrc', '') or s_data.get('imgSrc', '')
                        
                        if news_data['title']:
                            return news_data
                    except json.JSONDecodeError:
                        pass
                break
        
        # 方法2: 从mu属性获取URL
        mu_url = item.get('mu', '')
        if mu_url:
            news_data['url'] = mu_url
        
        # 方法3: 传统DOM解析作为备选
        # 提取标题和链接
        title_elem = item.select_one('h3 a')
        if title_elem:
            news_data['title'] = self._clean_html_tags(title_elem.get_text(strip=True))
            if not news_data['url']:
                news_data['url'] = title_elem.get('href', '')
        
        # 提取概要
        if not news_data['summary']:
            summary_elem = item.select_one('span.c-color-text') or \
                           item.select_one('.c-abstract')
            if summary_elem:
                news_data['summary'] = self._clean_html_tags(summary_elem.get_text(strip=True))[:200]
        
        # 提取封面图片
        if not news_data['cover']:
            img_elem = item.select_one('img.c-img') or item.select_one('img[src*="http"]')
            if img_elem:
                news_data['cover'] = img_elem.get('src', '') or img_elem.get('data-src', '')
        
        # 提取来源
        if not news_data['source']:
            source_elem = item.select_one('span.c-color-gray')
            if source_elem:
                source_text = source_elem.get_text(strip=True)
                # 提取来源名称（移除时间部分）
                source_match = re.match(r'^([^\d]+)', source_text)
                if source_match:
                    news_data['source'] = source_match.group(1).strip()
        
        return news_data
    
    def search_multiple_pages(self, keyword: str, pages: int = 3) -> List[Dict]:
        """
        搜索多页新闻
        
        :param keyword: 搜索关键字
        :param pages: 页数
        :return: 新闻列表
        """
        all_results = []
        
        for page in range(1, pages + 1):
            results = self.search(keyword, page)
            all_results.extend(results)
            
            if not results:
                break  # 没有更多结果
        
        # 去重（根据URL）
        seen_urls = set()
        unique_results = []
        for item in all_results:
            if item['url'] and item['url'] not in seen_urls:
                seen_urls.add(item['url'])
                unique_results.append(item)
        
        return unique_results


# 创建全局爬虫实例
crawler = BaiduNewsCrawler()


def fetch_news(keyword: str, pages: int = 1) -> List[Dict]:
    """
    获取新闻数据的便捷函数
    
    :param keyword: 搜索关键字
    :param pages: 页数
    :return: 新闻列表，每条包含 title, summary, cover, url, source
    """
    if pages == 1:
        return crawler.search(keyword)
    return crawler.search_multiple_pages(keyword, pages)


# 测试代码
if __name__ == '__main__':
    # 测试抓取
    keyword = "西昌"
    print(f"正在搜索关键字: {keyword}")
    
    results = fetch_news(keyword, pages=1)
    
    print(f"\n共获取 {len(results)} 条新闻:\n")
    for i, news in enumerate(results, 1):
        print(f"--- 第 {i} 条 ---")
        print(f"标题: {news['title']}")
        print(f"概要: {news['summary'][:100]}..." if len(news['summary']) > 100 else f"概要: {news['summary']}")
        print(f"封面: {news['cover']}")
        print(f"原始URL: {news['url']}")
        print(f"来源: {news['source']}")
        print()
